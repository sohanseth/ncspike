NeuralConnexions — Product Vision
Working spec · v0.4 · Updated for the three-pane workspace, Memory trust layer, and Signals/Insights direction.
1. The product in one line
A calm, trustworthy intelligence layer that turns scattered signals across your life and work into a clear morning, a transparent memory, and patterns you would not have noticed yourself.
2. Why it exists
Knowledge workers do not have a productivity problem. They have an attention and continuity problem. Information arrives faster than they can interpret it, context is split across tools, and there is no system that quietly notices what is becoming meaningful over time.
NeuralConnexions (NC) is built to be the opposite of an inbox: a place that is finite, calm, and earns trust by showing its reasoning.
3. Who it is for
Operators, founders, and senior ICs juggling many threads of work and life.
People who want AI assistance but refuse to hand over judgment to a black box.
Users who value precision over volume — a small number of correct, sourced answers per day.
4. Design principles
Practical and trustworthy first. Every AI claim shows what NC believes, where it came from, when it was last used, and a confidence.
Calm by default. Spacious, minimal, dark glassmorphic. No notification noise, no dashboards-of-dashboards.
User in control. Every inferred fact is editable, deletable, or markable as wrong — and corrections propagate.
Show the seams. Distinguish AI-inferred from user-confirmed. Distinguish recent from stale.
Discovery, not decoration. Visualizations only earn their place when they answer 'what is this, why is it connected, can I trust it?'
5. The workspace shape
NC is structured as a three-pane workspace: a slim icon rail, a list pane (what to look at), and a detail pane (what to do). This shape is consistent across every module so the user never has to relearn navigation.
Modules
Today — the morning briefing: actions, schedule, follow-ups, suggested drafts with sources.
Chat — conversational interface with the same memory and sources.
Memory — the trust layer (see §6).
Inbox, Calendar, Follow-ups, Compose — connective tissue around the briefing.
6. Memory: the trust layer
Memory is the heart of the product. It is not a notes app and not a vector blob — it is a transparent record of what NC believes about the user, organized into clear human categories: People, Projects, Preferences, Deadlines, Writing style, Recurring commitments, and Ignored / corrected assumptions.
Every memory item shows
What NC believes (a short, plain-language statement).
Source (where it came from — e.g., a WhatsApp thread, a calendar event, a previous brief).
When it was last used (and in which output).
Confidence (high / medium / low, with the reason).
Edit · Delete · Mark wrong controls — corrections change future drafts.
7. Memory has four views
List (default)
Categorized, editable, scannable. This is where trust is built and maintained. List is always the home of Memory.
Graph (exploration)
A read-only relationship map built on a structural layer, not a floating cloud of facts. Nodes are clustered by category (People, Projects, Deadlines…). Edges carry typed labels ('works on', 'meets with', 'due'). Visual state encodes meaning: solid ring = confirmed, dotted = inferred, red = rejected, glow = recently used. The graph must answer three questions instantly: what is this memory, why is it connected, can I trust or change it. Interactions are deliberately limited to pan, zoom, click, expand, filter, and open side panel — no dragging, no manual edge drawing.
Signals (pattern detection)
Emerging branches: clusters of related items appearing across searches, notes, messages, and meetings over time. Each branch shows momentum, evidence count, cross-domain overlap, and a suggested next step (e.g., 'Save as Project'). This is the layer that turns raw memory into early awareness.
Insights (AI suggestions)
Higher-order interpretations of how branches combine into projects, opportunities, or risks. Insights are explicitly marked as suggestions and link back to the underlying evidence.
8. Surfacing intelligence on Today
High-confidence signals appear as a single 'Pattern you may be missing' card on Today. One card, not a feed. It links into Memory → Signals so the user can inspect the evidence before acting. This is the product's flagship moment:
Show me the patterns in my life and work that are becoming meaningful before I fully notice them myself.
9. Visual language
Dark glassmorphic surface with a deep violet-black background and soft radial glows.
Type: Inter for body, Space Grotesk for display, JetBrains Mono for labels and metadata.
Color: a violet primary with a cyan accent glow, used sparingly to mark recency, confidence, and AI-authored content.
Density: spacious and minimal — generous whitespace, small but precise typographic hierarchy, no decorative chrome.
10. What NC is not
Not a chat-only assistant. Chat is one surface, not the product.
Not a CRM, project tracker, or note-taking app. NC sits above those tools and reasons across them.
Not a dashboard of metrics. The output is sentences, drafts, and decisions — not charts.
Not a toy graph. The graph is a reading surface, not a sandbox.
11. Success looks like
A user opens Today and trusts the first three items enough to act on them within 60 seconds.
A user opens Memory and can correct a wrong fact in one click — and sees the correction reflected in the next draft.
Once a week, a Signal surfaces a pattern the user genuinely had not noticed, and they save it as a project.
The user describes NC to a friend as 'calm', 'sharp', and 'mine' — not as 'an AI tool'.
12. Open questions for the design critique
Is the three-pane shape still right when the graph and signals views need more horizontal room?
How do we visualize confidence without turning the UI into a dashboard?
Where does collaboration live — is NC strictly single-player, or does shared memory belong in v1?
What is the smallest set of integrations needed for Signals to feel real on day one?