import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Alert } from './ui/alert';
import { createScoutTask, getScoutTasks, type ScoutTask } from '../../lib/api';
import { Loader, Moon, CheckCircle2, XCircle, Clock, Sparkles } from 'lucide-react';

export function ScoutTest() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [tasks, setTasks] = useState<ScoutTask[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function handleCreateTask() {
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    try {
      const task = await createScoutTask(query.trim());
      console.log('Scout task created:', task);
      setTasks([task, ...tasks]);
      setQuery('');

      // Poll for completion
      pollTask(task.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create task');
      console.error('Scout task error:', err);
    } finally {
      setLoading(false);
    }
  }

  async function pollTask(taskId: string) {
    const maxAttempts = 30; // 30 seconds max
    let attempts = 0;

    const poll = async () => {
      if (attempts >= maxAttempts) {
        console.log('Polling timeout for task', taskId);
        return;
      }

      try {
        const allTasks = await getScoutTasks();
        const task = allTasks.find(t => t.id === taskId);

        if (task) {
          setTasks(prev => prev.map(t => t.id === taskId ? task : t));

          if (task.status === 'completed' || task.status === 'failed') {
            console.log('Task finished:', task);
            return;
          }
        }

        attempts++;
        setTimeout(poll, 1000); // Poll every second
      } catch (err) {
        console.error('Polling error:', err);
      }
    };

    poll();
  }

  async function loadTasks() {
    try {
      const allTasks = await getScoutTasks();
      setTasks(allTasks);
    } catch (err) {
      console.error('Failed to load tasks:', err);
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <Moon className="w-5 h-5 text-violet-400" />
          Test Scout Agent
        </h2>
        <p className="text-sm text-zinc-400 mt-1">
          Try overnight research powered by Claude (no OAuth needed)
        </p>
      </div>

      {error && (
        <Alert className="bg-red-950/20 border-red-900/50 text-red-200">
          <div className="flex items-start gap-2">
            <XCircle className="w-4 h-4 mt-0.5" />
            <div className="text-sm">{error}</div>
          </div>
        </Alert>
      )}

      <div className="flex gap-2">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleCreateTask()}
          placeholder="Try: 'Find the best Italian restaurants in SF' or 'Research AI safety frameworks'"
          className="bg-zinc-900 border-zinc-800 text-white flex-1"
        />
        <Button
          onClick={handleCreateTask}
          disabled={loading || !query.trim()}
          className="bg-violet-600 hover:bg-violet-700"
        >
          {loading ? <Loader className="w-4 h-4 animate-spin" /> : 'Run Scout'}
        </Button>
      </div>

      {tasks.length === 0 ? (
        <div className="text-center py-8">
          <Button onClick={loadTasks} variant="outline" size="sm">
            Load Previous Tasks
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-zinc-400">Scout Tasks</p>
            <Button onClick={loadTasks} variant="ghost" size="sm">
              Refresh
            </Button>
          </div>

          {tasks.map((task) => {
            const statusIcon = {
              pending: <Clock className="w-4 h-4 text-zinc-400" />,
              running: <Loader className="w-4 h-4 text-violet-400 animate-spin" />,
              completed: <CheckCircle2 className="w-4 h-4 text-emerald-400" />,
              failed: <XCircle className="w-4 h-4 text-red-400" />,
            }[task.status];

            return (
              <Card key={task.id} className="p-4 bg-zinc-900 border-zinc-800">
                <div className="flex items-start gap-3">
                  <div className="mt-1">{statusIcon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-white text-sm">{task.query}</p>
                      <span className={`text-xs px-2 py-0.5 rounded ${
                        task.status === 'completed' ? 'bg-emerald-950/50 text-emerald-400' :
                        task.status === 'failed' ? 'bg-red-950/50 text-red-400' :
                        task.status === 'running' ? 'bg-violet-950/50 text-violet-400' :
                        'bg-zinc-800 text-zinc-400'
                      }`}>
                        {task.status}
                      </span>
                    </div>

                    {task.status === 'completed' && task.result && (
                      <div className="mt-3 space-y-2">
                        <div className="text-sm text-zinc-300">
                          {task.result.summary}
                        </div>

                        {task.result.findings && task.result.findings.length > 0 && (
                          <div className="bg-zinc-950/50 border border-zinc-800 rounded-lg p-3 text-xs text-zinc-400">
                            {task.result.findings.map((finding, idx) => (
                              <div key={idx} className="mb-2 last:mb-0">
                                {finding.title && <div className="font-medium text-zinc-300 mb-1">{finding.title}</div>}
                                <div className="whitespace-pre-wrap">{finding.content}</div>
                              </div>
                            ))}
                          </div>
                        )}

                        {task.result.recommendations && task.result.recommendations.length > 0 && (
                          <div>
                            <p className="text-xs font-medium text-zinc-400 mb-1">Recommendations:</p>
                            <ul className="text-xs text-zinc-500 space-y-1">
                              {task.result.recommendations.map((rec, idx) => (
                                <li key={idx} className="flex items-start gap-2">
                                  <Sparkles className="w-3 h-3 text-violet-400 mt-0.5 flex-shrink-0" />
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}

                    {task.status === 'failed' && task.error && (
                      <div className="mt-2 text-xs text-red-400">
                        Error: {task.error}
                      </div>
                    )}

                    <div className="text-xs text-zinc-500 mt-2">
                      Created {new Date(task.createdAt).toLocaleTimeString()}
                      {task.completedAt && ` • Completed in ${Math.round((task.completedAt - task.createdAt) / 1000)}s`}
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-3 text-xs text-zinc-500">
        <p className="font-medium text-zinc-400 mb-2">How Scout works:</p>
        <ul className="space-y-1">
          <li>• Uses Claude API to research your query</li>
          <li>• Executes asynchronously on the server</li>
          <li>• Returns structured findings and recommendations</li>
          <li>• <strong className="text-amber-400">Note:</strong> Currently runs without app signals (add OAuth to enable context from your apps)</li>
        </ul>
      </div>
    </div>
  );
}
