import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { ConnectionsManager } from './ConnectionsManager';
import {
  Brain, Zap, Moon, ArrowRight, CheckCircle2, Sparkles, MessageCircle, Mail, Music, FileText, Linkedin
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface OnboardingProps {
  onComplete: () => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const { user } = useAuth();

  const totalSteps = 3;

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-zinc-400">Step {step} of {totalSteps}</p>
            <button
              onClick={onComplete}
              className="text-sm text-zinc-500 hover:text-zinc-400"
            >
              Skip for now
            </button>
          </div>
          <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-violet-500 transition-all duration-300"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1: Welcome */}
        {step === 1 && (
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-2xl mx-auto flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-white" />
            </div>

            <div>
              <h1 className="text-3xl font-bold text-white mb-3">
                Welcome to NC, {user?.name || 'there'}!
              </h1>
              <p className="text-lg text-zinc-400 max-w-md mx-auto">
                Your proactive life agent that learns from your digital life to help you stay on top of what matters.
              </p>
            </div>

            <div className="grid gap-4 text-left max-w-md mx-auto mt-8">
              <Card className="p-4 bg-zinc-900/50 border-zinc-800">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-violet-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MessageCircle className="w-5 h-5 text-violet-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-white mb-1">Voice-first interface</h3>
                    <p className="text-sm text-zinc-400">
                      Quick answers and deep research through natural conversation
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-4 bg-zinc-900/50 border-zinc-800">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-sky-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Brain className="w-5 h-5 text-sky-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-white mb-1">Cross-domain memory</h3>
                    <p className="text-sm text-zinc-400">
                      Connects insights from work, learning, family, and personal life
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-4 bg-zinc-900/50 border-zinc-800">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-fuchsia-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Moon className="w-5 h-5 text-fuchsia-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-white mb-1">Scout overnight research</h3>
                    <p className="text-sm text-zinc-400">
                      Delegate complex tasks and wake up to curated results
                    </p>
                  </div>
                </div>
              </Card>
            </div>

            <Button
              onClick={() => setStep(2)}
              size="lg"
              className="bg-violet-600 hover:bg-violet-700 text-white"
            >
              Get Started <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        )}

        {/* Step 2: Connect Apps */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-sky-500 to-cyan-500 rounded-2xl mx-auto flex items-center justify-center mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                Connect your apps
              </h2>
              <p className="text-zinc-400 max-w-md mx-auto">
                NC learns from signals across your apps to provide proactive suggestions and automate tasks.
              </p>
            </div>

            <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6">
              <ConnectionsManager />
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setStep(1)}
                variant="outline"
                size="lg"
                className="flex-1"
              >
                Back
              </Button>
              <Button
                onClick={() => setStep(3)}
                size="lg"
                className="flex-1 bg-violet-600 hover:bg-violet-700 text-white"
              >
                Continue <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Ready */}
        {step === 3 && (
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-white" />
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-3">
                You're all set!
              </h2>
              <p className="text-zinc-400 max-w-md mx-auto">
                NC is now learning from your connected apps and building your memory graph. Start with a voice query or explore your domains.
              </p>
            </div>

            <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 max-w-md mx-auto text-left space-y-3">
              <p className="text-sm font-medium text-white">Try asking NC:</p>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <div className="w-1 h-1 bg-violet-400 rounded-full mt-2" />
                  <p className="text-sm text-zinc-300">"What should I focus on today?"</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-1 h-1 bg-violet-400 rounded-full mt-2" />
                  <p className="text-sm text-zinc-300">"Find me a dress for Maya's wedding"</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-1 h-1 bg-violet-400 rounded-full mt-2" />
                  <p className="text-sm text-zinc-300">"Draft a post about what I'm learning"</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setStep(2)}
                variant="outline"
                size="lg"
                className="flex-1"
              >
                Back
              </Button>
              <Button
                onClick={onComplete}
                size="lg"
                className="flex-1 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700 text-white"
              >
                Start Using NC
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
