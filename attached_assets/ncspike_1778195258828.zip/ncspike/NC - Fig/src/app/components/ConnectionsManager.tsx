import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Alert } from './ui/alert';
import { initiateOAuth, getConnectionStatus, getConfiguredServices } from '../../lib/api';
import { Mail, Music, FileText, Linkedin, Check, Loader, AlertCircle } from 'lucide-react';

const SERVICES = [
  { id: 'gmail' as const, name: 'Gmail', icon: Mail, description: 'Read emails and calendar' },
  { id: 'spotify' as const, name: 'Spotify', icon: Music, description: 'Music listening history' },
  { id: 'notion' as const, name: 'Notion', icon: FileText, description: 'Notes and documents' },
  { id: 'linkedin' as const, name: 'LinkedIn', icon: Linkedin, description: 'Professional network' },
];

export function ConnectionsManager() {
  const [connections, setConnections] = useState<Record<string, boolean>>({});
  const [configured, setConfigured] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadConnectionStatus();
    loadConfiguredServices();
  }, []);

  async function loadConfiguredServices() {
    try {
      const services = await getConfiguredServices();
      setConfigured(services);
    } catch (error) {
      console.error('Failed to check configured services:', error);
    }
  }

  async function loadConnectionStatus() {
    try {
      const status = await getConnectionStatus();
      setConnections(status);
    } catch (error) {
      console.error('Failed to load connection status:', error);
    }
  }

  async function handleConnect(serviceId: typeof SERVICES[number]['id']) {
    setLoading(serviceId);
    setError(null);
    try {
      const authUrl = await initiateOAuth(serviceId);

      // Open OAuth in new window
      const width = 600;
      const height = 700;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;

      const popup = window.open(
        authUrl,
        `${serviceId}_oauth`,
        `width=${width},height=${height},left=${left},top=${top}`
      );

      // Listen for OAuth callback
      const messageHandler = (event: MessageEvent) => {
        if (event.data.type === 'oauth_success' && event.data.service === serviceId) {
          popup?.close();
          loadConnectionStatus();
          window.removeEventListener('message', messageHandler);
          setLoading(null);
        }
      };

      window.addEventListener('message', messageHandler);

      // Timeout after 5 minutes
      setTimeout(() => {
        window.removeEventListener('message', messageHandler);
        setLoading(null);
      }, 5 * 60 * 1000);

    } catch (error) {
      console.error(`Failed to connect to ${serviceId}:`, error);
      setError(error instanceof Error ? error.message : `Failed to connect to ${serviceId}`);
      setLoading(null);
    }
  }

  const hasAnyConfigured = Object.values(configured).some(v => v);
  const unconfiguredServices = SERVICES.filter(s => !configured[s.id]);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold text-white">Connected Apps</h2>
        <p className="text-sm text-zinc-400 mt-1">
          Connect your apps to let NC learn from your digital life
        </p>
      </div>

      {!hasAnyConfigured && (
        <Alert className="bg-amber-950/20 border-amber-900/50 text-amber-200">
          <AlertCircle className="w-4 h-4" />
          <div className="ml-2">
            <p className="font-medium">OAuth credentials not configured</p>
            <p className="text-sm text-amber-300/80 mt-1">
              To connect apps, add OAuth credentials in Supabase secrets. See SETUP.md for instructions.
            </p>
          </div>
        </Alert>
      )}

      {error && (
        <Alert className="bg-red-950/20 border-red-900/50 text-red-200">
          <AlertCircle className="w-4 h-4" />
          <div className="ml-2">
            <p className="text-sm">{error}</p>
          </div>
        </Alert>
      )}

      <div className="grid gap-3">
        {SERVICES.map((service) => {
          const Icon = service.icon;
          const isConnected = connections[service.id];
          const isConfigured = configured[service.id];
          const isLoading = loading === service.id;

          return (
            <Card key={service.id} className="p-4 bg-zinc-900 border-zinc-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-zinc-400" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-white">{service.name}</p>
                      {isConnected && (
                        <div className="flex items-center gap-1 text-xs text-emerald-400">
                          <Check className="w-3 h-3" />
                          <span>Connected</span>
                        </div>
                      )}
                      {!isConfigured && (
                        <div className="text-xs text-amber-400">
                          Not configured
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-zinc-400">{service.description}</p>
                  </div>
                </div>

                {!isConnected && (
                  <Button
                    onClick={() => handleConnect(service.id)}
                    disabled={isLoading || !isConfigured}
                    variant="outline"
                    size="sm"
                    title={!isConfigured ? 'Add OAuth credentials in Supabase to enable' : ''}
                  >
                    {isLoading ? (
                      <Loader className="w-4 h-4 animate-spin" />
                    ) : (
                      'Connect'
                    )}
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {unconfiguredServices.length > 0 && (
        <div className="text-xs text-zinc-500 bg-zinc-900/50 border border-zinc-800 rounded-lg p-3">
          <p className="font-medium text-zinc-400 mb-1">To enable {unconfiguredServices.map(s => s.name).join(', ')}:</p>
          <ol className="list-decimal list-inside space-y-1 text-zinc-500">
            <li>Create OAuth apps for each service</li>
            <li>Add credentials to Supabase secrets (see SETUP.md)</li>
            <li>Deploy the edge function</li>
          </ol>
        </div>
      )}

      <p className="text-xs text-zinc-500 mt-4">
        NC uses secure OAuth 2.0. We never store your passwords and only request read access.
      </p>
    </div>
  );
}
