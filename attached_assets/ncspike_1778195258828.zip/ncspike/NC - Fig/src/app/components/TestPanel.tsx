import { useState } from 'react';
import { ScoutTest } from './ScoutTest';
import { ConnectionsManager } from './ConnectionsManager';
import { Button } from './ui/button';
import { X, Moon, Link } from 'lucide-react';

type TestView = 'scout' | 'connections';

interface TestPanelProps {
  open: boolean;
  onClose: () => void;
}

export function TestPanel({ open, onClose }: TestPanelProps) {
  const [view, setView] = useState<TestView>('scout');

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-4" onClick={onClose}
      style={{ background: "rgba(10,5,24,0.75)", backdropFilter: "blur(12px)" }}>
      <div className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-2xl border border-primary/25 overflow-hidden shadow-2xl"
        style={{ background: "rgba(22,18,38,0.98)", boxShadow: "0 24px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(155,109,250,0.18)" }}
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.07]">
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-semibold text-white">Test Backend Features</h2>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 px-6 py-3 border-b border-white/[0.05]">
          <Button
            onClick={() => setView('scout')}
            variant={view === 'scout' ? 'default' : 'ghost'}
            size="sm"
            className={view === 'scout' ? 'bg-violet-600 hover:bg-violet-700' : ''}
          >
            <Moon className="w-4 h-4 mr-2" />
            Scout Agent
          </Button>
          <Button
            onClick={() => setView('connections')}
            variant={view === 'connections' ? 'default' : 'ghost'}
            size="sm"
            className={view === 'connections' ? 'bg-violet-600 hover:bg-violet-700' : ''}
          >
            <Link className="w-4 h-4 mr-2" />
            Connections
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {view === 'scout' && <ScoutTest />}
          {view === 'connections' && <ConnectionsManager />}
        </div>
      </div>
    </div>
  );
}
