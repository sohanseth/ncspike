import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router';
import { completeOAuth } from '../../lib/api';
import { Loader, CheckCircle, XCircle } from 'lucide-react';

interface OAuthCallbackProps {
  service: 'gmail' | 'spotify' | 'notion' | 'linkedin';
}

export function OAuthCallback({ service }: OAuthCallbackProps) {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const code = searchParams.get('code');
    const errorParam = searchParams.get('error');

    if (errorParam) {
      setStatus('error');
      setError(errorParam);
      return;
    }

    if (!code) {
      setStatus('error');
      setError('No authorization code received');
      return;
    }

    async function handleCallback() {
      try {
        await completeOAuth(service, code!);
        setStatus('success');

        // Notify parent window
        if (window.opener) {
          window.opener.postMessage(
            { type: 'oauth_success', service },
            window.location.origin
          );
        }

        // Auto-close after 1.5 seconds
        setTimeout(() => {
          window.close();
        }, 1500);
      } catch (err) {
        setStatus('error');
        setError(err instanceof Error ? err.message : 'Failed to complete OAuth');
      }
    }

    handleCallback();
  }, [service, searchParams]);

  const serviceName = service.charAt(0).toUpperCase() + service.slice(1);

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="text-center">
        {status === 'loading' && (
          <>
            <Loader className="w-12 h-12 text-zinc-400 animate-spin mx-auto mb-4" />
            <p className="text-white text-lg">Connecting to {serviceName}...</p>
            <p className="text-zinc-400 text-sm mt-2">Please wait</p>
          </>
        )}

        {status === 'success' && (
          <>
            <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
            <p className="text-white text-lg">Successfully connected to {serviceName}!</p>
            <p className="text-zinc-400 text-sm mt-2">This window will close automatically...</p>
          </>
        )}

        {status === 'error' && (
          <>
            <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <p className="text-white text-lg">Failed to connect to {serviceName}</p>
            <p className="text-red-400 text-sm mt-2">{error}</p>
            <button
              onClick={() => window.close()}
              className="mt-4 px-4 py-2 bg-zinc-800 text-white rounded-lg hover:bg-zinc-700"
            >
              Close
            </button>
          </>
        )}
      </div>
    </div>
  );
}
