import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { AuthForm } from './components/AuthForm';
import { Onboarding } from './components/Onboarding';
import { MainApp } from './App';
import { Loader } from 'lucide-react';

export function AppWrapper() {
  const { user, loading: authLoading } = useAuth();
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState<boolean | null>(null);

  useEffect(() => {
    if (user) {
      // Check if user has completed onboarding
      const onboarded = localStorage.getItem(`nc_onboarded_${user.id}`);
      setHasCompletedOnboarding(onboarded === 'true');
    } else {
      setHasCompletedOnboarding(null);
    }
  }, [user]);

  function handleOnboardingComplete() {
    if (user) {
      localStorage.setItem(`nc_onboarded_${user.id}`, 'true');
      setHasCompletedOnboarding(true);
    }
  }

  function handleAuthSuccess() {
    // Auth context will update automatically
  }

  // Loading state
  if (authLoading || (user && hasCompletedOnboarding === null)) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
        <div className="text-center">
          <Loader className="w-8 h-8 text-violet-500 animate-spin mx-auto mb-4" />
          <p className="text-zinc-400">Loading NC...</p>
        </div>
      </div>
    );
  }

  // Not authenticated
  if (!user) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
        <AuthForm onSuccess={handleAuthSuccess} />
      </div>
    );
  }

  // First time user
  if (!hasCompletedOnboarding) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  // Authenticated and onboarded - render main app
  return <MainApp />;
}
