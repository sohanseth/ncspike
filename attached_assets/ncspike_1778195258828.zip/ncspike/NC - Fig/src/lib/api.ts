import { projectId, publicAnonKey } from '/utils/supabase/info';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-3f2e08db`;

let accessToken: string | null = null;

export function setAccessToken(token: string) {
  accessToken = token;
}

export function getAccessToken(): string | null {
  return accessToken;
}

function getHeaders(): HeadersInit {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${accessToken || publicAnonKey}`,
  };
}

// Check which OAuth services are configured
export async function getConfiguredServices(): Promise<Record<string, boolean>> {
  const response = await fetch(`${API_BASE}/oauth/configured`, {
    headers: getHeaders(),
  });
  if (!response.ok) {
    return { gmail: false, spotify: false, notion: false, linkedin: false };
  }
  return await response.json();
}

// OAuth connections
export async function initiateOAuth(service: 'gmail' | 'spotify' | 'notion' | 'linkedin'): Promise<string> {
  const response = await fetch(`${API_BASE}/oauth/${service}`, {
    headers: getHeaders(),
  });
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || `Failed to initiate ${service} OAuth`);
  }
  const data = await response.json();
  if (data.error) {
    throw new Error(data.error);
  }
  return data.authUrl;
}

export async function completeOAuth(service: 'gmail' | 'spotify' | 'notion' | 'linkedin', code: string): Promise<void> {
  const response = await fetch(`${API_BASE}/oauth/callback/${service}`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({ code }),
  });
  if (!response.ok) {
    throw new Error(`Failed to complete ${service} OAuth: ${await response.text()}`);
  }
}

export async function getConnectionStatus(): Promise<Record<string, boolean>> {
  const response = await fetch(`${API_BASE}/connections/status`, {
    headers: getHeaders(),
  });
  if (!response.ok) {
    throw new Error(`Failed to get connection status: ${await response.text()}`);
  }
  const data = await response.json();
  return data;
}

// Signals
export interface Signal {
  id: string;
  source: string;
  type: string;
  content: any;
  timestamp: number;
  domain: "personal" | "professional" | "learning";
}

export async function fetchSignals(service?: string): Promise<Signal[]> {
  const url = service ? `${API_BASE}/signals/${service}` : `${API_BASE}/signals`;
  const response = await fetch(url, {
    headers: getHeaders(),
  });
  if (!response.ok) {
    throw new Error(`Failed to fetch signals: ${await response.text()}`);
  }
  const data = await response.json();
  return data.signals;
}

// Scout tasks
export interface ScoutTask {
  id: string;
  userId: string;
  query: string;
  status: "pending" | "running" | "completed" | "failed";
  createdAt: number;
  completedAt?: number;
  result?: {
    summary: string;
    findings: any[];
    recommendations: string[];
  };
  error?: string;
}

export async function createScoutTask(query: string): Promise<ScoutTask> {
  const response = await fetch(`${API_BASE}/scout`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({ query }),
  });
  if (!response.ok) {
    throw new Error(`Failed to create Scout task: ${await response.text()}`);
  }
  const data = await response.json();
  return data.task;
}

export async function getScoutTasks(): Promise<ScoutTask[]> {
  const response = await fetch(`${API_BASE}/scout`, {
    headers: getHeaders(),
  });
  if (!response.ok) {
    throw new Error(`Failed to fetch Scout tasks: ${await response.text()}`);
  }
  const data = await response.json();
  return data.tasks;
}

export async function getScoutTask(taskId: string): Promise<ScoutTask> {
  const response = await fetch(`${API_BASE}/scout/${taskId}`, {
    headers: getHeaders(),
  });
  if (!response.ok) {
    throw new Error(`Failed to fetch Scout task: ${await response.text()}`);
  }
  const data = await response.json();
  return data.task;
}
