import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";
import * as kv from "./kv_store.tsx";
import { getAuthenticatedUser, storeToken, getToken } from "./auth.tsx";
import { fetchAllSignals, fetchGmailSignals, fetchSpotifySignals, fetchNotionSignals, fetchLinkedInSignals } from "./connectors.tsx";
import { createScoutTask, getUserScoutTasks, getScoutTask, executeScoutTask } from "./scout.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-3f2e08db/health", (c) => {
  return c.json({ status: "ok" });
});

// Auth signup endpoint
app.post("/make-server-3f2e08db/auth/signup", async (c) => {
  const { email, password, name } = await c.req.json();

  if (!email || !password) {
    return c.json({ error: "Email and password are required" }, 400);
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  try {
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured
      email_confirm: true,
    });

    if (error) {
      console.error(`User signup error for ${email}: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ user: data.user });
  } catch (error) {
    console.error(`User signup exception: ${error}`);
    return c.json({ error: "Signup failed" }, 500);
  }
});

// Check which OAuth services are configured
app.get("/make-server-3f2e08db/oauth/configured", (c) => {
  return c.json({
    gmail: !!(Deno.env.get("GOOGLE_CLIENT_ID") && Deno.env.get("GOOGLE_CLIENT_SECRET")),
    spotify: !!(Deno.env.get("SPOTIFY_CLIENT_ID") && Deno.env.get("SPOTIFY_CLIENT_SECRET")),
    notion: !!(Deno.env.get("NOTION_CLIENT_ID") && Deno.env.get("NOTION_CLIENT_SECRET")),
    linkedin: !!(Deno.env.get("LINKEDIN_CLIENT_ID") && Deno.env.get("LINKEDIN_CLIENT_SECRET")),
  });
});

// OAuth initiation endpoints
app.get("/make-server-3f2e08db/oauth/gmail", (c) => {
  const clientId = Deno.env.get("GOOGLE_CLIENT_ID");
  if (!clientId) {
    return c.json({ error: "Gmail OAuth not configured. Please add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to Supabase secrets." }, 503);
  }
  const redirectUri = `${c.req.header("origin")}/oauth/callback/gmail`;
  const scopes = "https://www.googleapis.com/auth/gmail.readonly";
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scopes}&access_type=offline&prompt=consent`;
  return c.json({ authUrl });
});

app.get("/make-server-3f2e08db/oauth/spotify", (c) => {
  const clientId = Deno.env.get("SPOTIFY_CLIENT_ID");
  if (!clientId) {
    return c.json({ error: "Spotify OAuth not configured. Please add SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET to Supabase secrets." }, 503);
  }
  const redirectUri = `${c.req.header("origin")}/oauth/callback/spotify`;
  const scopes = "user-read-recently-played user-read-playback-state";
  const authUrl = `https://accounts.spotify.com/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scopes}`;
  return c.json({ authUrl });
});

app.get("/make-server-3f2e08db/oauth/notion", (c) => {
  const clientId = Deno.env.get("NOTION_CLIENT_ID");
  if (!clientId) {
    return c.json({ error: "Notion OAuth not configured. Please add NOTION_CLIENT_ID and NOTION_CLIENT_SECRET to Supabase secrets." }, 503);
  }
  const redirectUri = `${c.req.header("origin")}/oauth/callback/notion`;
  const authUrl = `https://api.notion.com/v1/oauth/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code`;
  return c.json({ authUrl });
});

app.get("/make-server-3f2e08db/oauth/linkedin", (c) => {
  const clientId = Deno.env.get("LINKEDIN_CLIENT_ID");
  if (!clientId) {
    return c.json({ error: "LinkedIn OAuth not configured. Please add LINKEDIN_CLIENT_ID and LINKEDIN_CLIENT_SECRET to Supabase secrets." }, 503);
  }
  const redirectUri = `${c.req.header("origin")}/oauth/callback/linkedin`;
  const scopes = "r_liteprofile r_emailaddress";
  const authUrl = `https://www.linkedin.com/oauth/v2/authorization?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scopes}`;
  return c.json({ authUrl });
});

// OAuth callback handlers
app.post("/make-server-3f2e08db/oauth/callback/gmail", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed during Gmail OAuth callback" }, 401);
  }

  const { code } = await c.req.json();
  const redirectUri = `${c.req.header("origin")}/oauth/callback/gmail`;

  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: Deno.env.get("GOOGLE_CLIENT_ID")!,
      client_secret: Deno.env.get("GOOGLE_CLIENT_SECRET")!,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error(`Gmail OAuth token exchange error: ${error}`);
    return c.json({ error: `Gmail OAuth failed: ${error}` }, 400);
  }

  const data = await response.json();
  await storeToken(userId, "gmail", {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: Date.now() + (data.expires_in * 1000),
  });

  return c.json({ success: true });
});

app.post("/make-server-3f2e08db/oauth/callback/spotify", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed during Spotify OAuth callback" }, 401);
  }

  const { code } = await c.req.json();
  const redirectUri = `${c.req.header("origin")}/oauth/callback/spotify`;

  const response = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": `Basic ${btoa(`${Deno.env.get("SPOTIFY_CLIENT_ID")}:${Deno.env.get("SPOTIFY_CLIENT_SECRET")}`)}`,
    },
    body: new URLSearchParams({
      code,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error(`Spotify OAuth token exchange error: ${error}`);
    return c.json({ error: `Spotify OAuth failed: ${error}` }, 400);
  }

  const data = await response.json();
  await storeToken(userId, "spotify", {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: Date.now() + (data.expires_in * 1000),
  });

  return c.json({ success: true });
});

app.post("/make-server-3f2e08db/oauth/callback/notion", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed during Notion OAuth callback" }, 401);
  }

  const { code } = await c.req.json();
  const redirectUri = `${c.req.header("origin")}/oauth/callback/notion`;

  const response = await fetch("https://api.notion.com/v1/oauth/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Basic ${btoa(`${Deno.env.get("NOTION_CLIENT_ID")}:${Deno.env.get("NOTION_CLIENT_SECRET")}`)}`,
    },
    body: JSON.stringify({
      code,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error(`Notion OAuth token exchange error: ${error}`);
    return c.json({ error: `Notion OAuth failed: ${error}` }, 400);
  }

  const data = await response.json();
  await storeToken(userId, "notion", {
    access_token: data.access_token,
  });

  return c.json({ success: true });
});

app.post("/make-server-3f2e08db/oauth/callback/linkedin", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed during LinkedIn OAuth callback" }, 401);
  }

  const { code } = await c.req.json();
  const redirectUri = `${c.req.header("origin")}/oauth/callback/linkedin`;

  const response = await fetch("https://www.linkedin.com/oauth/v2/accessToken", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: Deno.env.get("LINKEDIN_CLIENT_ID")!,
      client_secret: Deno.env.get("LINKEDIN_CLIENT_SECRET")!,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error(`LinkedIn OAuth token exchange error: ${error}`);
    return c.json({ error: `LinkedIn OAuth failed: ${error}` }, 400);
  }

  const data = await response.json();
  await storeToken(userId, "linkedin", {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: Date.now() + (data.expires_in * 1000),
  });

  return c.json({ success: true });
});

// Check connection status for each service
app.get("/make-server-3f2e08db/connections/status", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed while checking connection status" }, 401);
  }

  const services = ["gmail", "spotify", "notion", "linkedin"];
  const status: Record<string, boolean> = {};

  for (const service of services) {
    const token = await getToken(userId, service);
    status[service] = !!token;
  }

  return c.json(status);
});

// Fetch signals from all connected apps
app.get("/make-server-3f2e08db/signals", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed while fetching signals" }, 401);
  }

  try {
    const signals = await fetchAllSignals(userId);
    return c.json({ signals });
  } catch (error) {
    console.error(`Error fetching signals for user ${userId}: ${error}`);
    return c.json({ error: `Failed to fetch signals: ${error}` }, 500);
  }
});

// Fetch signals from specific service
app.get("/make-server-3f2e08db/signals/:service", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed while fetching service signals" }, 401);
  }

  const service = c.req.param("service");

  try {
    let signals;
    switch (service) {
      case "gmail":
        signals = await fetchGmailSignals(userId);
        break;
      case "spotify":
        signals = await fetchSpotifySignals(userId);
        break;
      case "notion":
        signals = await fetchNotionSignals(userId);
        break;
      case "linkedin":
        signals = await fetchLinkedInSignals(userId);
        break;
      default:
        return c.json({ error: `Unknown service: ${service}` }, 400);
    }
    return c.json({ signals });
  } catch (error) {
    console.error(`Error fetching ${service} signals for user ${userId}: ${error}`);
    return c.json({ error: `Failed to fetch ${service} signals: ${error}` }, 500);
  }
});

// Scout task management
app.post("/make-server-3f2e08db/scout", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed while creating Scout task" }, 401);
  }

  const { query } = await c.req.json();
  if (!query) {
    return c.json({ error: "Query is required" }, 400);
  }

  try {
    const task = await createScoutTask(userId, query);
    // Execute task asynchronously (in production, use a queue)
    executeScoutTask(task.id, userId).catch(err =>
      console.error(`Background Scout task execution failed: ${err}`)
    );
    return c.json({ task });
  } catch (error) {
    console.error(`Error creating Scout task for user ${userId}: ${error}`);
    return c.json({ error: `Failed to create Scout task: ${error}` }, 500);
  }
});

app.get("/make-server-3f2e08db/scout", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed while fetching Scout tasks" }, 401);
  }

  try {
    const tasks = await getUserScoutTasks(userId);
    return c.json({ tasks });
  } catch (error) {
    console.error(`Error fetching Scout tasks for user ${userId}: ${error}`);
    return c.json({ error: `Failed to fetch Scout tasks: ${error}` }, 500);
  }
});

app.get("/make-server-3f2e08db/scout/:taskId", async (c) => {
  const userId = await getAuthenticatedUser(c.req.header("Authorization"));
  if (!userId) {
    return c.json({ error: "Unauthorized: User authentication failed while fetching Scout task" }, 401);
  }

  const taskId = c.req.param("taskId");

  try {
    const task = await getScoutTask(userId, taskId);
    if (!task) {
      return c.json({ error: "Task not found" }, 404);
    }
    return c.json({ task });
  } catch (error) {
    console.error(`Error fetching Scout task ${taskId} for user ${userId}: ${error}`);
    return c.json({ error: `Failed to fetch Scout task: ${error}` }, 500);
  }
});

Deno.serve(app.fetch);