import { refreshTokenIfNeeded } from "./auth.tsx";

export interface Signal {
  id: string;
  source: string;
  type: string;
  content: any;
  timestamp: number;
  domain: "personal" | "professional" | "learning";
}

// Gmail connector - fetch recent emails
export async function fetchGmailSignals(userId: string): Promise<Signal[]> {
  const token = await refreshTokenIfNeeded(userId, "gmail");
  if (!token) {
    throw new Error("Gmail not connected or token expired");
  }

  const response = await fetch(
    "https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=10&q=is:unread",
    {
      headers: {
        "Authorization": `Bearer ${token.access_token}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error(`Gmail API error: ${await response.text()}`);
  }

  const data = await response.json();
  const messages = data.messages || [];

  const signals: Signal[] = [];
  for (const msg of messages) {
    const detailResponse = await fetch(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}`,
      {
        headers: {
          "Authorization": `Bearer ${token.access_token}`,
        },
      }
    );

    if (detailResponse.ok) {
      const detail = await detailResponse.json();
      const subject = detail.payload.headers.find((h: any) => h.name === "Subject")?.value || "No subject";
      const from = detail.payload.headers.find((h: any) => h.name === "From")?.value || "Unknown";

      signals.push({
        id: `gmail-${msg.id}`,
        source: "gmail",
        type: "email",
        content: {
          subject,
          from,
          snippet: detail.snippet,
          threadId: msg.threadId,
        },
        timestamp: parseInt(detail.internalDate),
        domain: "professional", // Could be smarter with classification
      });
    }
  }

  return signals;
}

// Spotify connector - fetch recent listening history
export async function fetchSpotifySignals(userId: string): Promise<Signal[]> {
  const token = await refreshTokenIfNeeded(userId, "spotify");
  if (!token) {
    throw new Error("Spotify not connected or token expired");
  }

  const response = await fetch(
    "https://api.spotify.com/v1/me/player/recently-played?limit=20",
    {
      headers: {
        "Authorization": `Bearer ${token.access_token}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error(`Spotify API error: ${await response.text()}`);
  }

  const data = await response.json();

  return (data.items || []).map((item: any) => ({
    id: `spotify-${item.played_at}`,
    source: "spotify",
    type: "music",
    content: {
      track: item.track.name,
      artist: item.track.artists.map((a: any) => a.name).join(", "),
      album: item.track.album.name,
      playedAt: item.played_at,
    },
    timestamp: new Date(item.played_at).getTime(),
    domain: "personal",
  }));
}

// Notion connector - fetch recent pages
export async function fetchNotionSignals(userId: string): Promise<Signal[]> {
  const token = await refreshTokenIfNeeded(userId, "notion");
  if (!token) {
    throw new Error("Notion not connected or token expired");
  }

  const response = await fetch("https://api.notion.com/v1/search", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token.access_token}`,
      "Notion-Version": "2022-06-28",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      filter: {
        property: "object",
        value: "page",
      },
      sort: {
        direction: "descending",
        timestamp: "last_edited_time",
      },
      page_size: 10,
    }),
  });

  if (!response.ok) {
    throw new Error(`Notion API error: ${await response.text()}`);
  }

  const data = await response.json();

  return (data.results || []).map((page: any) => ({
    id: `notion-${page.id}`,
    source: "notion",
    type: "note",
    content: {
      title: page.properties?.title?.title?.[0]?.plain_text || "Untitled",
      url: page.url,
      lastEdited: page.last_edited_time,
    },
    timestamp: new Date(page.last_edited_time).getTime(),
    domain: "learning",
  }));
}

// LinkedIn connector - fetch recent posts/connections
export async function fetchLinkedInSignals(userId: string): Promise<Signal[]> {
  const token = await refreshTokenIfNeeded(userId, "linkedin");
  if (!token) {
    throw new Error("LinkedIn not connected or token expired");
  }

  // LinkedIn's API is more restricted, this is a simplified example
  const response = await fetch("https://api.linkedin.com/v2/me", {
    headers: {
      "Authorization": `Bearer ${token.access_token}`,
    },
  });

  if (!response.ok) {
    throw new Error(`LinkedIn API error: ${await response.text()}`);
  }

  const profile = await response.json();

  return [{
    id: `linkedin-profile`,
    source: "linkedin",
    type: "profile",
    content: {
      firstName: profile.localizedFirstName,
      lastName: profile.localizedLastName,
    },
    timestamp: Date.now(),
    domain: "professional",
  }];
}

// Fetch all signals from all connected apps
export async function fetchAllSignals(userId: string): Promise<Signal[]> {
  const signals: Signal[] = [];

  const connectors = [
    { name: "gmail", fn: fetchGmailSignals },
    { name: "spotify", fn: fetchSpotifySignals },
    { name: "notion", fn: fetchNotionSignals },
    { name: "linkedin", fn: fetchLinkedInSignals },
  ];

  for (const connector of connectors) {
    try {
      const connectorSignals = await connector.fn(userId);
      signals.push(...connectorSignals);
    } catch (error) {
      console.log(`Failed to fetch ${connector.name} signals for user ${userId}: ${error}`);
      // Continue with other connectors
    }
  }

  return signals.sort((a, b) => b.timestamp - a.timestamp);
}
