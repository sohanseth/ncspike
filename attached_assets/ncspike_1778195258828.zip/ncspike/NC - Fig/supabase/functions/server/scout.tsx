import Anthropic from "npm:@anthropic-ai/sdk@0.32.1";
import * as kv from "./kv_store.tsx";
import { fetchAllSignals } from "./connectors.tsx";

const anthropic = new Anthropic({
  apiKey: Deno.env.get("ANTHROPIC_API_KEY"),
});

export interface ScoutTask {
  id: string;
  userId: string;
  query: string;
  status: "pending" | "running" | "completed" | "failed";
  createdAt: number;
  completedAt?: number;
  result?: {
    summary: string;
    findings: any[];
    recommendations: string[];
  };
  error?: string;
}

// Create a new Scout task
export async function createScoutTask(userId: string, query: string): Promise<ScoutTask> {
  const task: ScoutTask = {
    id: `scout-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    userId,
    query,
    status: "pending",
    createdAt: Date.now(),
  };

  await kv.set(`scout:${userId}:${task.id}`, task);
  return task;
}

// Get all Scout tasks for a user
export async function getUserScoutTasks(userId: string): Promise<ScoutTask[]> {
  const tasks = await kv.getByPrefix(`scout:${userId}:`);
  return tasks.sort((a: ScoutTask, b: ScoutTask) => b.createdAt - a.createdAt);
}

// Get a specific Scout task
export async function getScoutTask(userId: string, taskId: string): Promise<ScoutTask | null> {
  return await kv.get(`scout:${userId}:${taskId}`);
}

// Execute a Scout task with Claude
export async function executeScoutTask(taskId: string, userId: string): Promise<void> {
  const task = await getScoutTask(userId, taskId);
  if (!task) {
    throw new Error(`Scout task ${taskId} not found`);
  }

  // Update status to running
  task.status = "running";
  await kv.set(`scout:${userId}:${taskId}`, task);

  try {
    // Fetch user's signals from connected apps
    const signals = await fetchAllSignals(userId);

    // Build context from signals
    const signalContext = signals.map(s =>
      `[${s.source}] ${s.type}: ${JSON.stringify(s.content)}`
    ).join("\n");

    // Use Claude to perform deep research
    const message = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4096,
      messages: [
        {
          role: "user",
          content: `You are NC, a proactive life agent. The user has delegated this research task to you: "${task.query}"

Here is context from the user's connected apps:

${signalContext}

Please conduct thorough research and provide:
1. A summary of what you found
2. Detailed findings organized by relevance
3. Actionable recommendations

Be comprehensive and consider the user's context from their signals.`,
        },
      ],
    });

    const responseText = message.content[0].type === "text" ? message.content[0].text : "";

    // Parse Claude's response (simplified - you'd want better parsing)
    const result = {
      summary: responseText.split("\n")[0] || "Research completed",
      findings: [
        { title: "Research Results", content: responseText }
      ],
      recommendations: extractRecommendations(responseText),
    };

    // Update task with results
    task.status = "completed";
    task.completedAt = Date.now();
    task.result = result;
    await kv.set(`scout:${userId}:${taskId}`, task);

  } catch (error) {
    console.error(`Scout task ${taskId} failed: ${error}`);
    task.status = "failed";
    task.error = error instanceof Error ? error.message : String(error);
    await kv.set(`scout:${userId}:${taskId}`, task);
  }
}

// Helper to extract recommendations from Claude's response
function extractRecommendations(text: string): string[] {
  const recommendations: string[] = [];
  const lines = text.split("\n");
  let inRecommendations = false;

  for (const line of lines) {
    if (line.toLowerCase().includes("recommendation")) {
      inRecommendations = true;
      continue;
    }
    if (inRecommendations && line.trim().startsWith("-")) {
      recommendations.push(line.trim().substring(1).trim());
    }
  }

  return recommendations.length > 0 ? recommendations : ["Review the findings above for next steps"];
}

// Background worker to process pending Scout tasks
export async function processScoutQueue(): Promise<void> {
  // Get all pending tasks across all users
  const allTasks = await kv.getByPrefix("scout:");
  const pendingTasks = allTasks.filter((task: ScoutTask) => task.status === "pending");

  console.log(`Processing ${pendingTasks.length} pending Scout tasks`);

  for (const task of pendingTasks) {
    try {
      await executeScoutTask(task.id, task.userId);
    } catch (error) {
      console.error(`Failed to execute Scout task ${task.id}: ${error}`);
    }
  }
}
