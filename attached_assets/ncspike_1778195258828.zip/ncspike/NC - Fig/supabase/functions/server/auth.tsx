import { createClient } from "jsr:@supabase/supabase-js@2.49.8";
import * as kv from "./kv_store.tsx";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

export interface OAuthToken {
  access_token: string;
  refresh_token?: string;
  expires_at?: number;
  scope?: string;
}

// Store OAuth tokens for a user and service
export async function storeToken(userId: string, service: string, token: OAuthToken): Promise<void> {
  await kv.set(`oauth:${userId}:${service}`, token);
}

// Get OAuth token for a user and service
export async function getToken(userId: string, service: string): Promise<OAuthToken | null> {
  return await kv.get(`oauth:${userId}:${service}`);
}

// Refresh token if expired
export async function refreshTokenIfNeeded(userId: string, service: string): Promise<OAuthToken | null> {
  const token = await getToken(userId, service);
  if (!token) return null;

  // If no expiry or not expired yet, return current token
  if (!token.expires_at || token.expires_at > Date.now()) {
    return token;
  }

  // Token expired, attempt refresh
  if (!token.refresh_token) {
    console.error(`Token expired for ${service} but no refresh token available for user ${userId}`);
    return null;
  }

  try {
    const refreshed = await refreshToken(service, token.refresh_token);
    await storeToken(userId, service, refreshed);
    return refreshed;
  } catch (error) {
    console.error(`Failed to refresh token for ${service}:`, error);
    return null;
  }
}

async function refreshToken(service: string, refreshToken: string): Promise<OAuthToken> {
  switch (service) {
    case "gmail":
      return await refreshGoogleToken(refreshToken);
    case "spotify":
      return await refreshSpotifyToken(refreshToken);
    case "notion":
      return await refreshNotionToken(refreshToken);
    case "linkedin":
      return await refreshLinkedInToken(refreshToken);
    default:
      throw new Error(`Unknown service: ${service}`);
  }
}

async function refreshGoogleToken(refreshToken: string): Promise<OAuthToken> {
  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: Deno.env.get("GOOGLE_CLIENT_ID")!,
      client_secret: Deno.env.get("GOOGLE_CLIENT_SECRET")!,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }),
  });

  if (!response.ok) {
    throw new Error(`Google token refresh failed: ${await response.text()}`);
  }

  const data = await response.json();
  return {
    access_token: data.access_token,
    refresh_token: refreshToken, // Google doesn't return new refresh token
    expires_at: Date.now() + (data.expires_in * 1000),
  };
}

async function refreshSpotifyToken(refreshToken: string): Promise<OAuthToken> {
  const response = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": `Basic ${btoa(`${Deno.env.get("SPOTIFY_CLIENT_ID")}:${Deno.env.get("SPOTIFY_CLIENT_SECRET")}`)}`,
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
    }),
  });

  if (!response.ok) {
    throw new Error(`Spotify token refresh failed: ${await response.text()}`);
  }

  const data = await response.json();
  return {
    access_token: data.access_token,
    refresh_token: data.refresh_token || refreshToken,
    expires_at: Date.now() + (data.expires_in * 1000),
  };
}

async function refreshNotionToken(refreshToken: string): Promise<OAuthToken> {
  // Notion tokens don't expire, but keeping structure consistent
  return {
    access_token: refreshToken,
  };
}

async function refreshLinkedInToken(refreshToken: string): Promise<OAuthToken> {
  const response = await fetch("https://www.linkedin.com/oauth/v2/accessToken", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: Deno.env.get("LINKEDIN_CLIENT_ID")!,
      client_secret: Deno.env.get("LINKEDIN_CLIENT_SECRET")!,
    }),
  });

  if (!response.ok) {
    throw new Error(`LinkedIn token refresh failed: ${await response.text()}`);
  }

  const data = await response.json();
  return {
    access_token: data.access_token,
    refresh_token: data.refresh_token || refreshToken,
    expires_at: Date.now() + (data.expires_in * 1000),
  };
}

// Verify user is authenticated via Supabase Auth
export async function getAuthenticatedUser(authHeader: string | null): Promise<string | null> {
  if (!authHeader) return null;

  const token = authHeader.split(" ")[1];
  if (!token) return null;

  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return null;

  return user.id;
}
