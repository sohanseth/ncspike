# NC - Neural Connexions

**Your proactive life agent powered by AI**

NC connects to your apps (Gmail, Spotify, Notion, LinkedIn) to extract signals, build a cross-domain memory graph, and provide proactive coaching. Delegate complex research tasks overnight and wake up to curated results.

## What's Built

### ✅ Complete Authentication System
- Sign up / Sign in with Supabase Auth
- User sessions with access token management
- Protected routes and API calls

### ✅ Onboarding Flow
- 3-step welcome experience for new users
- Explains NC's core features
- Guides users through app connections
- Personalized setup for each user

### ✅ Backend Infrastructure
- **OAuth flows** for Gmail, Spotify, Notion, LinkedIn
- **Token management** with automatic refresh
- **Signal fetching** from all connected apps
- **Scout system** for overnight research using Claude API
- **Supabase Edge Functions** (Hono web server)
- **Secure storage** for OAuth tokens and user data

### ✅ Frontend Features
- Voice-first interface (quick answers + deep research)
- Domain tiles (Learning, Professional, Social, Family, Personal)
- Action Queue with max 4 items
- Mind Map, Memory, Signals, Scout task views
- Chat and Compose modals
- Connections Manager for OAuth setup
- OAuth callback handlers

### 📚 Documentation
- `SETUP.md` — Backend setup, OAuth credentials, API configuration
- `DEPLOYMENT.md` — Deploying to staging subdomain, DNS setup, testing
- This file — Project overview and quick start

## Quick Start

### 1. Deploy Backend
```bash
# In Figma Make settings
Click "Deploy Edge Function"
```

### 2. Add Secrets
You've already added:
- ✅ `ANTHROPIC_API_KEY`

Still need OAuth credentials (see `SETUP.md`):
- `GOOGLE_CLIENT_ID` + `GOOGLE_CLIENT_SECRET`
- `SPOTIFY_CLIENT_ID` + `SPOTIFY_CLIENT_SECRET`
- `NOTION_CLIENT_ID` + `NOTION_CLIENT_SECRET`
- `LINKEDIN_CLIENT_ID` + `LINKEDIN_CLIENT_SECRET`

### 3. Test Locally
1. Open the preview in Figma Make
2. Sign up with test account
3. Complete onboarding
4. Try connecting an app (will fail without OAuth credentials)
5. Test voice/chat features

### 4. Deploy to Staging
Follow `DEPLOYMENT.md` to deploy to:
- `app.neuralconnexions.com` or
- `beta.neuralconnexions.com`

## Architecture

```
┌─────────────────────────────────────────────────┐
│  Frontend (React + Tailwind PWA)                │
│  - Auth (Supabase Auth)                         │
│  - Voice/Chat UI                                │
│  - Domain tiles + Action Queue                  │
│  - Mind Map / Memory / Signals / Scout          │
└─────────────────┬───────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────┐
│  Backend (Supabase Edge Function - Hono)        │
│  - OAuth initiation + callback handlers         │
│  - Token storage + refresh                      │
│  - Signal fetching from apps                    │
│  - Scout task execution (Claude API)            │
└─────────────────┬───────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────┐
│  Data Layer (Supabase)                          │
│  - Postgres (kv_store for tokens/tasks)         │
│  - Auth (user management)                       │
│  - Edge Functions (serverless compute)          │
└─────────────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────┐
│  External APIs                                  │
│  - Gmail, Spotify, Notion, LinkedIn (OAuth)     │
│  - Anthropic Claude (Scout research)            │
└─────────────────────────────────────────────────┘
```

## Key Files

### Frontend
- `src/app/App.tsx` — Main app component (wrapped with auth)
- `src/app/AppWrapper.tsx` — Auth gate + onboarding flow
- `src/contexts/AuthContext.tsx` — Auth state management
- `src/lib/api.ts` — API client for backend calls
- `src/lib/supabase.ts` — Supabase auth helpers
- `src/app/components/AuthForm.tsx` — Sign up / sign in UI
- `src/app/components/Onboarding.tsx` — 3-step onboarding
- `src/app/components/ConnectionsManager.tsx` — OAuth connection UI
- `src/app/components/OAuthCallback.tsx` — OAuth redirect handler

### Backend
- `supabase/functions/server/index.tsx` — Main server + routes
- `supabase/functions/server/auth.tsx` — Token management
- `supabase/functions/server/connectors.tsx` — App signal fetching
- `supabase/functions/server/scout.tsx` — Scout task system
- `supabase/functions/server/kv_store.tsx` — Database helpers (auto-generated)

## API Endpoints

### Auth
- `POST /auth/signup` — Create new user

### OAuth
- `GET /oauth/{service}` — Get OAuth URL
- `POST /oauth/callback/{service}` — Complete OAuth

### Connections
- `GET /connections/status` — Check connected apps

### Signals
- `GET /signals` — All signals
- `GET /signals/{service}` — Service-specific signals

### Scout
- `POST /scout` — Create Scout task
- `GET /scout` — List all tasks
- `GET /scout/{taskId}` — Get task details + results

## User Flow

1. **Sign Up** → User creates account
2. **Onboarding** → 3-step intro + app connections
3. **Connect Apps** → OAuth to Gmail, Spotify, etc.
4. **Use NC** → Voice queries, domain exploration, Scout delegation
5. **Signals** → NC fetches data from connected apps
6. **Scout** → Overnight research tasks execute with Claude
7. **Results** → Wake up to curated findings

## Development Workflow

### Making Changes
1. Edit files in `src/` or `supabase/functions/server/`
2. Test in Figma Make preview
3. Deploy edge function (if backend changed)
4. Test in staging environment
5. Collect feedback from beta testers

### Adding New App Connectors
1. Add OAuth endpoint in `server/index.tsx`
2. Add token refresh logic in `server/auth.tsx`
3. Add signal fetching in `server/connectors.tsx`
4. Update `ConnectionsManager.tsx` with new service
5. Add OAuth callback route
6. Update documentation

## Costs (Estimated for Beta)

- **Supabase**: Free tier (500MB DB, 2GB bandwidth)
- **Anthropic API**: $5-20/month (Scout usage)
- **Make hosting**: Free
- **Domain**: $0-10/month

**Total: ~$5-30/month for 10-20 beta users**

## Limitations

### Current (Make Prototype)
- Not designed for production PII/sensitive data
- Limited to Make's infrastructure
- No custom email flows (auto-confirm for now)
- Basic error handling

### Future Migration Path
When ready for production:
1. Migrate frontend to Vercel/Netlify + Next.js
2. Keep Supabase backend (already production-ready)
3. Add proper email authentication
4. Implement rate limiting
5. Add monitoring/analytics
6. Set up proper CI/CD

## Next Steps

### Immediate (Beta Launch)
1. ✅ Deploy edge function
2. ✅ Add Anthropic API key
3. ⏳ Add OAuth credentials for connectors
4. ⏳ Test all features end-to-end
5. ⏳ Deploy to staging subdomain
6. ⏳ Invite 5-10 beta testers

### Short Term (1-2 weeks)
- Integrate real signals into UI (currently using mock data)
- Wire up Scout UI to backend API
- Add error boundaries and better error messages
- Improve mobile PWA experience
- Add user feedback mechanism

### Medium Term (1 month)
- Add more connectors (WhatsApp, Slack, Calendar)
- Improve Claude prompts for Scout research
- Build memory graph visualization
- Add signal-based proactive suggestions
- Implement notification system

### Long Term (2-3 months)
- Migrate off Make to production stack
- Add social login (Google, Apple)
- Build admin dashboard
- Implement usage analytics
- Consider monetization strategy
- Launch public beta

## Security Notes

- OAuth tokens stored server-side only
- Passwords hashed by Supabase Auth
- Access tokens validated on every API call
- CORS configured (currently `*` for dev, needs tightening)
- No sensitive data in client localStorage
- Service role key never exposed to frontend

## Support

- Check `SETUP.md` for backend configuration
- Check `DEPLOYMENT.md` for deployment help
- Review server logs in Supabase dashboard
- Test in browser DevTools console for client errors

## License

Private beta — not for redistribution

---

Built with ❤️ using Figma Make, React, Tailwind, Supabase, and Claude
