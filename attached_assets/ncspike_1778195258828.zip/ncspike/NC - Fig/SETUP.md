# NC Backend Setup Guide

Your NC app now has a full backend infrastructure for connecting to Gmail, Spotify, Notion, LinkedIn, and running Scout overnight research tasks.

## Architecture

```
Frontend (React + Tailwind)
    ↓
Supabase Edge Function (Hono server)
    ↓
App APIs (Gmail, Spotify, etc.) + Claude API
```

## What's been built

### Backend (`/supabase/functions/server/`)
- **`index.tsx`** — Main server with OAuth routes, signal fetching, Scout task management
- **`auth.tsx`** — OAuth token storage, refresh logic, user authentication
- **`connectors.tsx`** — Data fetching from Gmail, Spotify, Notion, LinkedIn
- **`scout.tsx`** — Background research system using Claude API

### Frontend
- **`/src/lib/api.ts`** — API client for all backend calls
- **`/src/app/components/ConnectionsManager.tsx`** — UI for connecting apps
- **`/src/app/components/OAuthCallback.tsx`** — OAuth redirect handler

## Setup Steps

### 1. Deploy the Supabase Edge Function
Go to https://figma.com/make and click **Settings** → **Deploy Edge Function**

This uploads your server code to Supabase. Do this whenever you modify server files.

### 2. Add OAuth Credentials

You need to create OAuth apps for each service and add their credentials as Supabase secrets.

#### Gmail (Google)
1. Go to https://console.cloud.google.com/apis/credentials
2. Create OAuth 2.0 Client ID (Web application)
3. Add authorized redirect URI: `https://[your-make-app-url]/oauth/callback/gmail`
4. Copy Client ID and Client Secret
5. Add to Supabase secrets:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`

#### Spotify
1. Go to https://developer.spotify.com/dashboard/applications
2. Create an app
3. Add redirect URI: `https://[your-make-app-url]/oauth/callback/spotify`
4. Copy Client ID and Client Secret
5. Add to Supabase secrets:
   - `SPOTIFY_CLIENT_ID`
   - `SPOTIFY_CLIENT_SECRET`

#### Notion
1. Go to https://www.notion.so/my-integrations
2. Create new integration
3. Add redirect URI: `https://[your-make-app-url]/oauth/callback/notion`
4. Copy OAuth client ID and secret
5. Add to Supabase secrets:
   - `NOTION_CLIENT_ID`
   - `NOTION_CLIENT_SECRET`

#### LinkedIn
1. Go to https://www.linkedin.com/developers/apps
2. Create app
3. Add redirect URI: `https://[your-make-app-url]/oauth/callback/linkedin`
4. Copy Client ID and Client Secret
5. Add to Supabase secrets:
   - `LINKEDIN_CLIENT_ID`
   - `LINKEDIN_CLIENT_SECRET`

### 3. Add Anthropic API Key

You already received a prompt to add this. If you haven't:
1. Get your API key from https://console.anthropic.com
2. Add to Supabase as `ANTHROPIC_API_KEY`

### 4. Add Routing for OAuth Callbacks

You'll need to add routes in your app for the OAuth callbacks. Here's how:

**Option A:** Use React Router (if you add routing to App.tsx)
```tsx
import { Routes, Route } from 'react-router';
import { OAuthCallback } from './components/OAuthCallback';

<Routes>
  <Route path="/" element={<MainApp />} />
  <Route path="/oauth/callback/gmail" element={<OAuthCallback service="gmail" />} />
  <Route path="/oauth/callback/spotify" element={<OAuthCallback service="spotify" />} />
  <Route path="/oauth/callback/notion" element={<OAuthCallback service="notion" />} />
  <Route path="/oauth/callback/linkedin" element={<OAuthCallback service="linkedin" />} />
</Routes>
```

**Option B:** Simple hash-based routing (no additional dependencies)
Check `window.location.pathname` in App.tsx and render OAuthCallback component if path matches.

### 5. Add ConnectionsManager to UI

Add the Connections Manager somewhere in your UI (maybe in the You drawer):

```tsx
import { ConnectionsManager } from './components/ConnectionsManager';

// In your You drawer or settings panel:
<ConnectionsManager />
```

## Testing

### On Laptop (Development)
1. Make sure Supabase Edge Function is deployed
2. Add OAuth credentials
3. Open the app in browser
4. Go to Connections Manager
5. Click "Connect" for a service (e.g., Gmail)
6. Complete OAuth flow
7. Check browser console for any errors

### On Phone (PWA)
1. Deploy your Make app
2. Open the deployed URL on your phone
3. Add to home screen (PWA install)
4. Test connections — OAuth should open in new tab/popup
5. Test voice features with microphone

## API Endpoints Reference

### OAuth
- `GET /oauth/{service}` — Get OAuth authorization URL
- `POST /oauth/callback/{service}` — Complete OAuth with authorization code

### Connections
- `GET /connections/status` — Check which apps are connected

### Signals
- `GET /signals` — Fetch signals from all connected apps
- `GET /signals/{service}` — Fetch signals from specific service

### Scout
- `POST /scout` — Create new Scout task (body: `{ query: string }`)
- `GET /scout` — Get all Scout tasks for user
- `GET /scout/{taskId}` — Get specific Scout task with results

## Common Issues

### "Unauthorized" errors
- Make sure you're passing the access token in Authorization header
- Implement Supabase Auth if you want multi-user support
- For now, the app uses anonymous access with `publicAnonKey`

### OAuth redirect fails
- Check that redirect URIs match exactly in OAuth app settings
- Make sure routing is set up correctly for `/oauth/callback/*` paths

### "Service not connected" errors
- User needs to complete OAuth flow first
- Check token storage in Supabase database (kv_store table)

### Scout tasks stay "pending"
- Verify `ANTHROPIC_API_KEY` is set correctly
- Check server logs in Supabase dashboard
- Tasks execute asynchronously — poll `GET /scout/{taskId}` to check status

## Next Steps

1. **Add user authentication** — Currently using anonymous access. Add Supabase Auth for multi-user support.
2. **Integrate signals into UI** — Display fetched signals in the Signals view
3. **Wire up Scout UI** — Connect the existing overnight tasks UI to the Scout API
4. **Add more connectors** — WhatsApp, Slack, banking (via Plaid), etc.
5. **Improve Claude prompts** — Enhance Scout research quality with better context and instructions
6. **Add caching** — Cache signals to reduce API calls
7. **Background sync** — Set up periodic signal fetching (cron jobs)

## Security Notes

- OAuth tokens are stored in Supabase (server-side)
- Never expose `SUPABASE_SERVICE_ROLE_KEY` to frontend
- For banking/sensitive data, use dedicated services like Plaid
- Make is NOT designed for production apps with PII — it's for prototyping
