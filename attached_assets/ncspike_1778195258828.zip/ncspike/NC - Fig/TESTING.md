# Testing NC Without OAuth

You can test NC's core features **without** setting up OAuth credentials. Here's what works right now:

## ✅ Features You Can Test Immediately

### 1. **Authentication System**
- Sign up with any email/password
- Sign in / Sign out
- Session persistence
- Protected routes

**How to test:**
1. Open the app
2. Create an account
3. Sign out and sign back in
4. Refresh the page (session should persist)

### 2. **Onboarding Flow**
- 3-step welcome experience
- Feature explanations
- Connections preview

**How to test:**
1. Sign up with a new account
2. Go through all 3 onboarding steps
3. Try clicking "Skip for now" to bypass

### 3. **Scout Agent (Overnight Research)** ⭐
**This is the big one!** Scout works with just the Anthropic API key (already configured).

**How to test:**
1. Click the **"Test"** button in the top bar (amber colored, next to "You")
2. Select **"Scout Agent"** tab
3. Enter a test query, for example:
   - "Research the top 5 AI safety frameworks"
   - "Find the best Italian restaurants in SF"
   - "Summarize the key concepts in quantum computing"
4. Click **"Run Scout"**
5. Watch the task status change: `pending` → `running` → `completed`
6. View the AI-generated research results

**What Scout does:**
- Creates a task with your query
- Executes on the server using Claude Sonnet 4
- Returns structured findings + recommendations
- Currently runs without app signals (will use them once OAuth is set up)

### 4. **UI/UX Features**
- Voice interface (UI only, no speech recognition yet)
- Domain tiles (Learning, Professional, Social, Family, Personal)
- Action Queue
- Chat modal
- Compose modal
- Mind Map / Memory / Signals views (mock data)
- You drawer

**How to test:**
1. Click domain tiles in the top bar
2. Open voice interface (microphone button)
3. Try Chat and Compose buttons
4. Click "You" to explore Mind Map, Memory, Signals

## ⏳ Features That Need OAuth Setup

These require OAuth credentials (see SETUP.md):

### **App Connections**
- Gmail signal fetching
- Spotify listening history
- Notion notes
- LinkedIn profile

**How to test (after setup):**
1. Click **"Test"** button → **"Connections"** tab
2. Click **"Connect"** for a service
3. Complete OAuth flow in popup
4. Service shows as "Connected" ✓

Once connected, Scout will use signals from your apps for better context.

## 🧪 Test Checklist

### Basic Flow
- [ ] Sign up works
- [ ] Sign in works
- [ ] Onboarding completes
- [ ] Can access main app

### Scout Agent
- [ ] Can create Scout task
- [ ] Task shows as "pending" then "running"
- [ ] Task completes with results
- [ ] Results show summary + findings + recommendations
- [ ] Can create multiple tasks

### Error Handling
- [ ] OAuth buttons disabled when not configured
- [ ] Helpful error messages shown
- [ ] Warning banner appears in Connections tab
- [ ] Instructions provided for setup

### Browser DevTools
- [ ] No console errors on page load
- [ ] Auth token stored in memory (check network tab)
- [ ] API calls go to correct Supabase URL
- [ ] Scout tasks poll correctly

## 🐛 Common Issues & Fixes

### "OAuth credentials not configured"
**Expected behavior!** This shows when you haven't added OAuth credentials yet. The Test panel will guide you through setup.

### Scout task stays "pending" forever
**Check:**
1. Is `ANTHROPIC_API_KEY` set in Supabase secrets?
2. Did you deploy the edge function?
3. Check Supabase logs for errors

**How to check:**
- Go to Supabase dashboard → Edge Functions → Logs
- Look for errors related to Scout execution

### "Unauthorized" errors
**Check:**
1. Are you signed in?
2. Does your session have a valid token?
3. Open DevTools → Application → Storage → check for auth data

### Scout returns generic results
**This is expected!** Without OAuth connections, Scout has no context from your apps. Results will be more generic research. Once you connect apps, Scout will incorporate signals for personalized results.

## 📊 What to Look For

### Good Signs ✅
- Tasks complete in 5-15 seconds
- Results are relevant to query
- UI updates automatically when task completes
- No console errors

### Bad Signs ❌
- Tasks stuck in "pending" > 30 seconds
- Console shows 401/403 errors
- Results are empty or error messages
- Page crashes or becomes unresponsive

## 🔄 Testing Scout Thoroughly

Try these queries to test different capabilities:

### Simple Research
- "What are the top 3 machine learning frameworks?"
- "Explain React Server Components"

### Complex Analysis
- "Compare the pros and cons of Notion vs Linear"
- "What are emerging trends in AI safety research?"

### Time-Sensitive (will be generic without news API)
- "What are the latest developments in quantum computing?"

## 📝 Taking Notes

As you test, note:
1. **What works well**
2. **What's confusing**
3. **What breaks**
4. **Ideas for improvement**

This feedback is gold for iteration!

## ✅ Success Criteria

You've successfully tested NC when:
- [x] Can sign up and sign in
- [x] Onboarding flow works
- [x] Scout agent creates tasks
- [x] Scout agent returns AI-generated results
- [x] Test panel shows connection status
- [x] No critical errors in console

## 🚀 Next Steps After Testing

1. **Add OAuth** for at least one service (Gmail recommended)
2. **Test with real signals** - Scout will be much more powerful
3. **Deploy to staging** subdomain for mobile testing
4. **Invite beta testers**

---

**TL;DR**: Click the **Test** button in the top bar. Try Scout Agent first - it works without any OAuth setup!
