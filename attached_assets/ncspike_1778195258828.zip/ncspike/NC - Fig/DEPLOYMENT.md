# NC Deployment Guide

## Overview

This guide covers deploying NC to your staging subdomain (`app.neuralconnexions.com` or `beta.neuralconnexions.com`) for private beta testing.

## Prerequisites

- ✅ Supabase project connected
- ✅ Anthropic API key configured
- ✅ OAuth credentials for app connectors (Gmail, Spotify, Notion, LinkedIn)
- Domain access to `neuralconnexions.com` or `neuralconnexions.ai`

## Step 1: Deploy Supabase Edge Function

### Via Figma Make UI
1. Go to https://figma.com/make
2. Open your NC project
3. Click **Settings** (gear icon)
4. Click **"Deploy Edge Function"**
5. Wait for deployment to complete

### Via Supabase CLI (Alternative)
```bash
# Install Supabase CLI
npm install -g supabase

# Login
supabase login

# Link to your project
supabase link --project-ref vskbtxtjxrqmmoqumsxu

# Deploy function
supabase functions deploy make-server-3f2e08db
```

## Step 2: Configure OAuth Redirect URIs

For each service, update OAuth app settings with your staging domain:

### Gmail (Google Cloud Console)
1. Go to https://console.cloud.google.com/apis/credentials
2. Edit your OAuth 2.0 Client ID
3. Add authorized redirect URI:
   ```
   https://app.neuralconnexions.com/oauth/callback/gmail
   ```
4. Save changes

### Spotify
1. Go to https://developer.spotify.com/dashboard/applications
2. Edit your app
3. Add redirect URI:
   ```
   https://app.neuralconnexions.com/oauth/callback/spotify
   ```
4. Save

### Notion
1. Go to https://www.notion.so/my-integrations
2. Edit your integration
3. Add redirect URI:
   ```
   https://app.neuralconnexions.com/oauth/callback/notion
   ```
4. Save

### LinkedIn
1. Go to https://www.linkedin.com/developers/apps
2. Edit your app
3. Add redirect URI:
   ```
   https://app.neuralconnexions.com/oauth/callback/linkedin
   ```
4. Save

## Step 3: Set Up Custom Domain

### Option A: Via Figma Make (if supported)
Check if Make supports custom domains in Settings → Domains

### Option B: Via Vercel/Netlify Proxy

If Make doesn't support custom domains, set up a reverse proxy:

#### Using Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Create vercel.json in project root
```

Create `vercel.json`:
```json
{
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "https://[your-make-app-url]/$1"
    }
  ]
}
```

Deploy:
```bash
vercel --prod
```

Then add custom domain in Vercel dashboard.

#### Using Netlify
Create `_redirects` file:
```
/*  https://[your-make-app-url]/:splat  200
```

Deploy via Netlify CLI or Git integration.

### Option C: Cloudflare Workers

Create a Worker that proxies to your Make app and add it to your domain.

## Step 4: Configure DNS

Add DNS records for your subdomain:

### For Vercel
```
Type: CNAME
Name: app (or beta)
Value: cname.vercel-dns.com
```

### For Netlify
```
Type: CNAME
Name: app (or beta)
Value: [your-app].netlify.app
```

### For Cloudflare Workers
Add your worker route to the subdomain in Cloudflare dashboard.

## Step 5: Test the Deployment

1. **Visit your staging URL**: `https://app.neuralconnexions.com`
2. **Sign up** with test account
3. **Complete onboarding**
4. **Connect at least one app** (Gmail recommended for testing)
5. **Test voice/chat** features
6. **Create a Scout task** and verify execution
7. **Check signals** from connected apps

### Test Checklist
- [ ] Auth sign up works
- [ ] Auth sign in works
- [ ] Onboarding flow completes
- [ ] OAuth connections work for all services
- [ ] Signals fetch from connected apps
- [ ] Scout tasks create and execute
- [ ] Voice interface works (desktop + mobile)
- [ ] Domain tiles navigation works
- [ ] Mind Map/Memory/Signals views load
- [ ] Mobile PWA install works

## Step 6: Monitor and Debug

### Check Server Logs
1. Go to https://supabase.com/dashboard/project/vskbtxtjxrqmmoqumsxu
2. Click **Edge Functions** → `make-server-3f2e08db`
3. View **Logs** tab for errors

### Check Client Errors
- Open browser DevTools → Console
- Look for network errors or API failures
- Check localStorage for auth tokens

### Common Issues

**"Unauthorized" errors**
- Check that access token is being sent in Authorization header
- Verify Supabase Auth session is active
- Check that SUPABASE_SERVICE_ROLE_KEY is set correctly

**OAuth redirects fail**
- Verify redirect URIs match exactly (https vs http, trailing slash)
- Check that OAuth credentials are set in Supabase secrets
- Ensure origin header is being passed correctly

**Scout tasks don't execute**
- Verify ANTHROPIC_API_KEY is set
- Check server logs for Claude API errors
- Ensure task creation returns pending status

**Signals don't fetch**
- Verify OAuth tokens are stored and valid
- Check token refresh logic in auth.tsx
- Look for API rate limiting errors

## Step 7: Invite Beta Testers

Once everything works:

1. **Create a beta landing page** (optional)
   - Explain what NC does
   - Collect email for waitlist
   - Send invite links

2. **Invite testers directly**
   - Send them: `https://app.neuralconnexions.com`
   - Provide guidance on what to test
   - Set up feedback channel (email, Slack, form)

3. **Monitor usage**
   - Track sign-ups in Supabase Auth dashboard
   - Monitor API usage/costs
   - Watch for error patterns in logs

## Migration to Production

When ready to move from beta to production domain:

1. Update all OAuth redirect URIs to production domain
2. Deploy to `neuralconnexions.ai` instead of subdomain
3. Set up proper email authentication (remove auto-confirm)
4. Add terms of service and privacy policy
5. Consider migrating off Make to:
   - Frontend: Vercel + Next.js
   - Backend: Supabase Edge Functions (keep as is)
   - Database: Supabase Postgres (keep as is)

## Cost Estimates (Beta Phase)

With 10-20 beta users:

- **Supabase**: Free tier (up to 500MB database, 2GB bandwidth)
- **Anthropic API**: ~$5-20/month (depends on Scout usage)
- **Make hosting**: Free (included in Make)
- **Custom domain**: $0-10/month (depends on provider)

Total: ~$5-30/month during beta

## Support

If you encounter issues:
1. Check server logs in Supabase dashboard
2. Review browser console errors
3. Test with different browsers/devices
4. Verify all secrets are set correctly
5. Check SETUP.md for detailed API configuration

## Security Checklist

Before going live:
- [ ] HTTPS enabled on all domains
- [ ] OAuth secrets stored in Supabase (not in code)
- [ ] SUPABASE_SERVICE_ROLE_KEY never exposed to frontend
- [ ] CORS configured correctly (not wildcard `*` in production)
- [ ] Rate limiting considered for API endpoints
- [ ] User data handling reviewed (GDPR compliance if EU users)
- [ ] No API keys committed to Git
- [ ] Content Security Policy configured
- [ ] Password requirements enforced (min 6 chars)
