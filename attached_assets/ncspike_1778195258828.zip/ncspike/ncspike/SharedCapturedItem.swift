import Foundation

// Shared between main app and NCShare extension via App Group storage.
// Keep this struct minimal — it must encode/decode across both targets.

struct SharedCapturedItem: Codable, Identifiable {
    let id: UUID
    let message: String
    let sender: String
    let taxonomy: String       // SharedTaxonomy.rawValue
    let capturedAt: Date

    init(
        id: UUID = UUID(),
        message: String,
        sender: String,
        taxonomy: String,
        capturedAt: Date = Date()
    ) {
        self.id = id
        self.message = message
        self.sender = sender
        self.taxonomy = taxonomy
        self.capturedAt = capturedAt
    }

    var fingerprint: String {
        ContentFingerprint.make(source: sender, text: message)
    }
}
