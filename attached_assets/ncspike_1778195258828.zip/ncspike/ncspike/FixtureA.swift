import Foundation

struct FixtureCalendarEvent {
    let title: String
    let time: String
    let rawText: String
}

struct FixtureGmailMessage {
    let sender: String
    let subject: String
    let snippet: String
}

struct FixtureWhatsAppShare {
    let sender: String
    let message: String
}

struct FixtureA {
    static let calendarEvents: [FixtureCalendarEvent] = [
        FixtureCalendarEvent(
            title: "Sprint planning",
            time: "09:00",
            rawText: "09:00 sprint planning"
        ),
        FixtureCalendarEvent(
            title: "1:1 with manager",
            time: "11:30",
            rawText: "11:30 1:1 with manager"
        ),
        FixtureCalendarEvent(
            title: "Ballet pickup — Maya",
            time: "16:30",
            rawText: "16:30 ballet pickup — Maya"
        )
    ]

    static let gmailMessages: [FixtureGmailMessage] = [
        FixtureGmailMessage(
            sender: "School",
            subject: "Lunch payment due Friday",
            snippet: "Lunch payment is due this Friday."
        ),
        FixtureGmailMessage(
            sender: "Mum",
            subject: "Christmas plans",
            snippet: "Sunday email asking about Christmas plans."
        ),
        FixtureGmailMessage(
            sender: "Tesco",
            subject: "Delivery confirmed for today",
            snippet: "Tesco delivery confirmed 17:00–19:00 today."
        ),
        FixtureGmailMessage(
            sender: "Work",
            subject: "Slack unread DM summary",
            snippet: "Slack notification summary for unread DMs."
        ),
        FixtureGmailMessage(
            sender: "Amazon",
            subject: "Order shipped — ballet shoes",
            snippet: "Amazon order shipped — ballet shoes."
        )
    ]

    static let whatsappShares: [FixtureWhatsAppShare] = [
        FixtureWhatsAppShare(
            sender: "Friend",
            message: "my mum is having hip surgery Wednesday morning — anxious"
        ),
        FixtureWhatsAppShare(
            sender: "Unknown",
            message: "Can you bring it Friday?"
        )
    ]
}
