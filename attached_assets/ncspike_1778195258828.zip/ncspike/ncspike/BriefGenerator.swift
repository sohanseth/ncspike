import Foundation
import FoundationModels

// MARK: — Parse defect

struct ParseDefect: CustomStringConvertible {
    let description: String
}

// MARK: — BriefGenerator

enum BriefGenerator {

    // MARK: Plan → prompt text

    static func planToPromptText(_ plan: BriefPlan) -> String {
        plan.items.enumerated().map { index, item in
            // Pre-combine verb + object into SUGGESTED_NEXT so the model cannot split them
            let suggestedNext = "\(item.suggestedActionVerb.rawValue) \(item.suggestedActionObject)"
            // Sanitise newlines — embedded newlines in titles/evidence corrupt the line-by-line
            // plan format and confuse both the model and the parser.
            let title = item.title.replacingOccurrences(of: "\n", with: " ")
            let evidence = item.evidence.replacingOccurrences(of: "\n", with: " ")
            return [
                "ITEM \(index + 1)",
                "TITLE: \(title)",
                "SOURCE: \(item.source.rawValue)",
                "CONFIDENCE: \(item.confidence.rawValue)",
                "TAXONOMY: \(item.taxonomy.rawValue)",
                "EVIDENCE: \(evidence)",
                "SUGGESTED_NEXT: \(suggestedNext)"
            ].joined(separator: "\n")
        }.joined(separator: "\n---\n")
    }

    // MARK: Planner + model pipeline

    static func generateRawWithModel(plan: BriefPlan) async throws -> String {
        let planText = planToPromptText(plan)
        let itemCount = plan.items.count

        let instructions = [
            "You rewrite a deterministic NC BriefPlan into Morning Brief cards.",
            "The plan is already approved. You are the wording layer only.",
            "",
            "OUTPUT RULE: Output exactly \(itemCount) cards. One card per ITEM. Separate cards with --- on its own line.",
            "Do NOT put blank lines inside a card. Fields run consecutively with no gaps.",
            "",
            "Hard rules:",
            "- One card per ITEM. Exactly \(itemCount) cards total.",
            "- Do not add items. Do not drop items.",
            "- Do not change SOURCE, CONFIDENCE, or TAXONOMY.",
            "- Do not invent facts. Do not infer across items.",
            "- NEXT must begin with the first word from SUGGESTED_NEXT.",
            "- Do not change the opening verb of SUGGESTED_NEXT.",
            "- Use EVIDENCE as the only factual basis.",
            "- For sensitiveHealthAdjacent: make action gentle and optional.",
            "- For ambiguous: do not guess the missing detail.",
            "- Forbidden in NEXT: will, should, must, remember, don't forget, ensure, make sure.",
            "- Keep WHY under 18 words. Keep NEXT under 14 words.",
            "",
            "Action rule — NEXT must be physically performable:",
            "GOOD: NEXT: Pack ballet shoes in Maya's bag tonight.",
            "BAD: NEXT: Don't forget about Maya's ballet shoes.",
            "",
            "Source rule — copy SOURCE exactly from the ITEM block. Never rephrase or combine:",
            "WRONG: SOURCE: WhatsApp",
            "WRONG: SOURCE: calendar, whatsapp",
            "CORRECT (exact copy): SOURCE: whatsappShare",
            "CORRECT (exact copy): SOURCE: calendar",
            "",
            "Required output format — no blank lines within a card, --- between cards:",
            "TITLE: ...",
            "WHY: ...",
            "SOURCE: ...",
            "CONFIDENCE: ...",
            "TAXONOMY: ...",
            "EVIDENCE: ...",
            "NEXT: ...",
            "---",
            "TITLE: ...",
            "WHY: ...",
            "SOURCE: ...",
            "CONFIDENCE: ...",
            "TAXONOMY: ...",
            "EVIDENCE: ...",
            "NEXT: ..."
        ].joined(separator: "\n")

        let prompt = "Output exactly \(itemCount) cards for this BriefPlan. One card per ITEM.\n\nBriefPlan:\n\(planText)"

        let session = LanguageModelSession(instructions: instructions)
        let response = try await session.respond(to: prompt)
        return response.content
    }

    // MARK: Text parser (model output → BriefItem cards)
    // Robust to: blank lines within cards, markdown bold/heading markers,
    // bare bold titles (no TITLE: prefix), and model echoing plan fields
    // (Suggested Action / Suggested Action Object) instead of NEXT.

    static func parseModelOutput(_ text: String) -> [BriefItem] {
        var items: [BriefItem] = []
        var currentFields: [String: String] = [:]

        func saveCurrentCard() {
            guard let title = currentFields["TITLE"], !title.isEmpty,
                  let why = currentFields["WHY"], !why.isEmpty else { return }

            // NEXT may come from: NEXT field, SUGGESTED_NEXT fallback (model echoed plan),
            // or composed from Suggested Action + Suggested Action Object.
            let next: String
            if let direct = currentFields["NEXT"], !direct.isEmpty {
                next = direct
            } else if let suggested = currentFields["SUGGESTED_NEXT"] ?? currentFields["SUGGESTED NEXT"],
                      !suggested.isEmpty {
                next = suggested
            } else if let verb = currentFields["SUGGESTED ACTION"], !verb.isEmpty {
                let obj = currentFields["SUGGESTED ACTION OBJECT"] ?? ""
                next = obj.isEmpty ? verb : "\(verb) \(obj)"
            } else {
                return
            }

            items.append(BriefItem(
                title: title,
                why: why,
                source: currentFields["SOURCE"] ?? "unknown",
                confidence: currentFields["CONFIDENCE"] ?? "Medium",
                nextAction: next
            ))
        }

        for line in text.components(separatedBy: "\n") {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.isEmpty || trimmed == "---" { continue }

            // Strip markdown formatting: **bold**, ### headings
            let cleaned = trimmed
                .replacingOccurrences(of: "**", with: "")
                .replacingOccurrences(of: "### ", with: "")
                .replacingOccurrences(of: "## ", with: "")
                .trimmingCharacters(in: .whitespaces)
                .trimmingCharacters(in: CharacterSet(charactersIn: "*- "))
            guard !cleaned.isEmpty else { continue }

            // Lines with no ": " are implicit TITLE boundaries
            // (model sometimes outputs title as bold/heading without a field label)
            if !cleaned.contains(": ") {
                if currentFields["TITLE"] != nil {
                    saveCurrentCard()
                    currentFields = [:]
                }
                currentFields["TITLE"] = cleaned
                continue
            }

            guard let colonRange = cleaned.range(of: ": ") else { continue }
            let key = String(cleaned[cleaned.startIndex..<colonRange.lowerBound])
                .uppercased()
            let value = String(cleaned[colonRange.upperBound...])
                .trimmingCharacters(in: .whitespaces)
            guard !key.isEmpty, !value.isEmpty else { continue }

            // New TITLE field = new card boundary
            if key == "TITLE" && currentFields["TITLE"] != nil {
                saveCurrentCard()
                currentFields = [:]
            }

            currentFields[key] = value
        }

        saveCurrentCard()
        return items
    }

    // MARK: Safety validator (parsed cards vs plan contract)

    static func validateCards(_ cards: [BriefItem], against plan: BriefPlan) -> [ParseDefect] {
        var defects: [ParseDefect] = []

        func normalizedContractValue(_ value: String) -> String {
            value
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .trimmingCharacters(in: CharacterSet(charactersIn: ".,;:"))
                .lowercased()
        }

        if cards.count != plan.items.count {
            defects.append(ParseDefect(
                description: "Count mismatch: plan=\(plan.items.count) parsed=\(cards.count)"
            ))
        }

        let allowedVerbs = Set(SuggestedActionVerb.allCases.map { $0.rawValue.lowercased() })
        let forbiddenPhrases = [
            "remember", "don't forget", "be productive", "have a good day",
            "stay focused", "make sure", "ensure", "don't miss"
        ]

        for (i, card) in cards.enumerated() {
            let prefix = "Card \(i + 1)"
            guard i < plan.items.count else {
                defects.append(ParseDefect(description: "\(prefix): extra card added by model"))
                continue
            }
            let planned = plan.items[i]

            if normalizedContractValue(card.source) != normalizedContractValue(planned.source.rawValue) {
                defects.append(ParseDefect(
                    description: "\(prefix): SOURCE changed '\(planned.source.rawValue)' → '\(card.source)'"
                ))
            }
            if normalizedContractValue(card.confidence) != normalizedContractValue(planned.confidence.rawValue) {
                defects.append(ParseDefect(
                    description: "\(prefix): CONFIDENCE changed '\(planned.confidence.rawValue)' → '\(card.confidence)'"
                ))
            }

            let firstWord = card.nextAction.split(separator: " ").first.map(String.init)?.lowercased() ?? ""

            // Verb must be whitelisted
            if !allowedVerbs.contains(firstWord) {
                defects.append(ParseDefect(
                    description: "\(prefix): action verb '\(firstWord)' not in whitelist"
                ))
            }

            // Verb must match what the planner specified
            let plannedVerb = planned.suggestedActionVerb.rawValue.lowercased()
            if !firstWord.isEmpty && firstWord != plannedVerb {
                defects.append(ParseDefect(
                    description: "\(prefix): verb changed '\(plannedVerb)' → '\(firstWord)'"
                ))
            }

            let nextLower = card.nextAction.lowercased()
            for phrase in forbiddenPhrases where nextLower.contains(phrase) {
                defects.append(ParseDefect(
                    description: "\(prefix): forbidden phrase '\(phrase)' in NEXT"
                ))
            }
        }

        return defects
    }

    // MARK: Combined: plan → model → parsed cards + defects
    // Chunks into batches of 5 to stay within Foundation Models output budget.
    // NOTE: Foundation Models serialises concurrent LanguageModelSession calls at the OS level —
    // parallel Swift tasks give no latency benefit. Chunks run sequentially.
    // Latency scales linearly: ~7s per chunk. Cap brief at 8–10 items (2 chunks) for <15s generation.

    private static let chunkSize = 5

    static func generateCardsFromPlan(_ plan: BriefPlan) async throws -> (cards: [BriefItem], raw: String, defects: [ParseDefect]) {
        let allItems = plan.items
        var allCards: [BriefItem] = []
        var rawChunks: [String] = []

        var offset = 0
        var chunkIndex = 1
        while offset < allItems.count {
            let end = min(offset + chunkSize, allItems.count)
            let slice = Array(allItems[offset..<end])
            let chunkPlan = BriefPlan(items: slice)
            let raw = try await generateRawWithModel(plan: chunkPlan)
            let parsed = parseModelOutput(raw)
            // Safety net: restore SOURCE/CONFIDENCE from plan contract when model drops them.
            // Positional — only applied when parsed count matches slice count.
            let cards: [BriefItem] = parsed.enumerated().map { (i, card) in
                guard i < slice.count else { return card }
                let planned = slice[i]
                return BriefItem(
                    id: planned.id,
                    fingerprint: planned.fingerprint,
                    title: card.title,
                    why: card.why,
                    source: planned.source.rawValue,
                    confidence: planned.confidence.rawValue,
                    nextAction: "\(planned.suggestedActionVerb.rawValue) \(planned.suggestedActionObject)"
                )
            }
            allCards.append(contentsOf: cards)
            rawChunks.append("=== Chunk \(chunkIndex) (items \(offset + 1)–\(end)) ===\n\(raw)")
            offset += chunkSize
            chunkIndex += 1
        }

        let defects = validateCards(allCards, against: plan)
        return (cards: allCards, raw: rawChunks.joined(separator: "\n\n"), defects: defects)
    }

    // MARK: Static baseline (no model — reference only)

    static func generateFromFixture() -> [BriefItem] {
        return [
            BriefItem(
                title: "Lunch payment due Friday",
                why: "The school email says lunch payment is due this Friday.",
                source: "Email",
                confidence: "High",
                nextAction: "Pay it or confirm it is already handled."
            ),
            BriefItem(
                title: "Tesco delivery may clash with ballet pickup",
                why: "Tesco delivery is 17:00-19:00 and Maya's ballet pickup is at 16:30.",
                source: "Email + Calendar",
                confidence: "Medium",
                nextAction: "Check whether Ravi can receive the delivery."
            ),
            BriefItem(
                title: "Ballet shoes arriving today",
                why: "Amazon says ballet shoes shipped, but no source says Maya needs them today.",
                source: "Email",
                confidence: "Medium",
                nextAction: "Check delivery timing before assuming they are needed today."
            ),
            BriefItem(
                title: "Possible follow-up: friend's mum has surgery Wednesday",
                why: "Your friend shared that her mum's hip surgery is Wednesday morning.",
                source: "WhatsApp share",
                confidence: "Medium",
                nextAction: "Save a gentle reminder to ask how it went?"
            ),
            BriefItem(
                title: "Ambiguous Friday request",
                why: "A WhatsApp message says can you bring it Friday with no context for it.",
                source: "WhatsApp share",
                confidence: "Low",
                nextAction: "Ask for clarification instead of assuming."
            )
        ]
    }
}
