import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct BriefItem: Identifiable {
    let id: UUID
    let fingerprint: String
    let title: String
    let why: String
    let source: String
    let confidence: String
    let nextAction: String

    init(
        id: UUID = UUID(),
        fingerprint: String? = nil,
        title: String,
        why: String,
        source: String,
        confidence: String,
        nextAction: String
    ) {
        self.id = id
        self.fingerprint = fingerprint ?? ContentFingerprint.make(source: source, text: "\(title) \(why) \(nextAction)")
        self.title = title
        self.why = why
        self.source = source
        self.confidence = confidence
        self.nextAction = nextAction
    }
}

let starterBriefItems = [
    BriefItem(
        title: "Add a few real items",
        why: "Paste or share messages, then generate the Morning Brief.",
        source: "App",
        confidence: "High",
        nextAction: "Add context and generate your brief."
    )
]

struct ContentView: View {
    @State private var profile = UserContentStore.loadProfile()
    @State private var pastedItems: [UserCapturedItem] = UserContentStore.loadPastedItems()
    @State private var sharedItems: [SharedCapturedItem] = SharedStorage.loadAll()
    @State private var feedback: [BriefFeedback] = UserContentStore.loadFeedback()
    @State private var briefItems: [BriefItem] = starterBriefItems
    @State private var pasteText = ""
    @State private var isGenerating = false
    @State private var statusText = "Ready for real input."
    @State private var errorMessage: String?
    @State private var parseDefects: [ParseDefect] = []
    @State private var rawModelOutput = ""

    private var allInputCount: Int {
        pastedItems.count + sharedItems.count
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Morning Brief")
                            .font(.largeTitle)
                            .bold()

                        Text(statusText)
                            .foregroundStyle(.secondary)
                    }

                    ProfilePanel(profile: $profile) {
                        UserContentStore.saveProfile(profile)
                        statusText = "Personal context saved."
                    }

                    InputPanel(
                        pasteText: $pasteText,
                        pastedItems: pastedItems,
                        sharedItems: sharedItems,
                        onAddPaste: addPastedItem,
                        onReloadShared: reloadState,
                        onClearInputs: clearInputs
                    )

                    Button {
                        Task { await generateBrief() }
                    } label: {
                        Text(isGenerating ? "Generating..." : "Generate Morning Brief")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isGenerating || allInputCount == 0)

                    if let errorMessage {
                        Text("Error: \(errorMessage)")
                            .font(.caption)
                            .foregroundStyle(.red)
                    }

                    BriefList(
                        items: briefItems,
                        feedback: feedback,
                        onFeedback: recordFeedback
                    )

                    FeedbackPanel(feedback: feedback) {
                        UserContentStore.clearFeedback()
                        feedback = []
                        statusText = "Feedback cleared."
                    }

                    if !parseDefects.isEmpty {
                        DiagnosticsPanel(title: "Parser Defects", lines: parseDefects.map(\.description))
                    }

                    if !rawModelOutput.isEmpty {
                        DisclosureGroup("Raw Model Output") {
                            Text(rawModelOutput)
                                .font(.caption)
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding()
                        .background(.thinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }

                    DiagnosticsExportPanel(snapshot: diagnosticsSnapshot) {
                        copyDiagnostics()
                    }
                }
                .padding()
            }
            .navigationTitle("NC")
            .onAppear(perform: reloadState)
        }
    }

    private func reloadState() {
        profile = UserContentStore.loadProfile()
        pastedItems = UserContentStore.loadPastedItems()
        sharedItems = SharedStorage.loadAll()
        feedback = UserContentStore.loadFeedback()
    }

    private func addPastedItem() {
        UserContentStore.addPastedItem(pasteText)
        pasteText = ""
        reloadState()
        statusText = "Added pasted item. \(allInputCount) item(s) ready."
    }

    private func clearInputs() {
        UserContentStore.clearPastedItems()
        SharedStorage.clear()
        pastedItems = []
        sharedItems = []
        briefItems = starterBriefItems
        parseDefects = []
        rawModelOutput = ""
        statusText = "Inputs cleared."
    }

    private func generateBrief() async {
        isGenerating = true
        errorMessage = nil
        parseDefects = []
        rawModelOutput = ""
        reloadState()

        let plan = DeterministicPlanner.makePlan(
            profile: profile,
            pastedItems: pastedItems,
            sharedItems: sharedItems,
            feedback: feedback
        )

        guard !plan.items.isEmpty else {
            briefItems = starterBriefItems
            statusText = "No actionable items after feedback filters."
            isGenerating = false
            return
        }

        do {
            let result = try await BriefGenerator.generateCardsFromPlan(plan)
            briefItems = result.cards
            parseDefects = result.defects
            rawModelOutput = result.raw
            statusText = "Generated \(result.cards.count) of max \(DeterministicPlanner.maxBriefItems) items."
        } catch {
            errorMessage = error.localizedDescription
            statusText = "Generation failed."
        }

        isGenerating = false
    }

    private func recordFeedback(_ kind: BriefFeedbackKind, for item: BriefItem) {
        let entry = BriefFeedback(
            itemID: item.id,
            fingerprint: item.fingerprint,
            title: item.title,
            source: item.source,
            kind: kind
        )
        UserContentStore.addFeedback(entry)
        feedback = UserContentStore.loadFeedback()

        switch kind {
        case .confirm:
            statusText = "Confirmed. Similar items get a small priority boost."
        case .wrong:
            statusText = "Marked wrong. This item is demoted on the next brief."
        case .ignore:
            briefItems.removeAll { $0.id == item.id }
            statusText = "Ignored. This item is hidden from future briefs."
        }
    }

    private var diagnosticsSnapshot: String {
        var lines: [String] = []
        lines.append("NC Spike diagnostics")
        lines.append("Generated: \(Date().formatted(date: .abbreviated, time: .standard))")
        lines.append("Profile complete enough: \(profile.isCompleteEnough)")
        lines.append("Pasted count: \(pastedItems.count)")
        lines.append("Shared count: \(sharedItems.count)")
        lines.append("Feedback count: \(feedback.count)")
        lines.append("Brief count: \(briefItems.count)")
        lines.append("")
        lines.append("Inputs:")
        for item in pastedItems {
            lines.append("- paste | \(item.taxonomy) | \(item.text)")
        }
        for item in sharedItems {
            lines.append("- share | \(item.taxonomy) | \(item.message)")
        }
        lines.append("")
        lines.append("Brief:")
        for item in briefItems {
            lines.append("- \(item.title) | \(item.source) | \(item.confidence) | \(item.nextAction)")
        }
        lines.append("")
        lines.append("Feedback:")
        for item in feedback {
            lines.append("- \(item.kind.rawValue) | \(item.title) | \(item.source)")
        }
        lines.append("")
        lines.append("Parser defects:")
        for defect in parseDefects {
            lines.append("- \(defect.description)")
        }
        return lines.joined(separator: "\n")
    }

    private func copyDiagnostics() {
        #if canImport(UIKit)
        UIPasteboard.general.string = diagnosticsSnapshot
        statusText = "Debug log copied."
        #else
        statusText = "Debug log unavailable on this platform."
        #endif
    }
}

struct ProfilePanel: View {
    @Binding var profile: PersonalContext
    let onSave: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Personal Context")
                .font(.headline)

            TextField("Your name", text: $profile.userName)
                .textFieldStyle(.roundedBorder)
            TextField("Partner / co-parent", text: $profile.partnerName)
                .textFieldStyle(.roundedBorder)
            TextField("Children / household names", text: $profile.childNames)
                .textFieldStyle(.roundedBorder)
            TextField("City", text: $profile.city)
                .textFieldStyle(.roundedBorder)

            Button("Save Context", action: onSave)
                .buttonStyle(.bordered)
        }
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct InputPanel: View {
    @Binding var pasteText: String
    let pastedItems: [UserCapturedItem]
    let sharedItems: [SharedCapturedItem]
    let onAddPaste: () -> Void
    let onReloadShared: () -> Void
    let onClearInputs: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Inputs")
                    .font(.headline)
                Spacer()
                Text("\(pastedItems.count + sharedItems.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            TextEditor(text: $pasteText)
                .frame(minHeight: 88)
                .padding(8)
                .background(.background)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(.quaternary)
                )

            HStack {
                Button("Add Paste", action: onAddPaste)
                    .buttonStyle(.borderedProminent)
                    .disabled(pasteText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Button("Reload Shares", action: onReloadShared)
                    .buttonStyle(.bordered)
                Button("Clear", action: onClearInputs)
                    .buttonStyle(.bordered)
            }

            InputList(title: "Pasted", items: pastedItems.map { $0.text })
            InputList(title: "Shared", items: sharedItems.map { $0.message })
        }
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct InputList: View {
    let title: String
    let items: [String]

    var body: some View {
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                    Text(item)
                        .font(.caption)
                        .lineLimit(2)
                }
            }
        }
    }
}

struct BriefList: View {
    let items: [BriefItem]
    let feedback: [BriefFeedback]
    let onFeedback: (BriefFeedbackKind, BriefItem) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Brief")
                .font(.headline)

            ForEach(items) { item in
                BriefCard(
                    item: item,
                    feedbackKind: feedback.first { $0.itemID == item.id }?.kind,
                    onFeedback: onFeedback
                )
            }
        }
    }
}

struct BriefCard: View {
    let item: BriefItem
    let feedbackKind: BriefFeedbackKind?
    let onFeedback: (BriefFeedbackKind, BriefItem) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(item.title)
                    .font(.headline)
                Spacer()
                if let feedbackKind {
                    Text(feedbackKind.rawValue.capitalized)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }

            Text(item.why)

            HStack {
                Text("Source: \(item.source)")
                Spacer()
                Text(item.confidence)
                    .bold()
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            Text("Next: \(item.nextAction)")
                .font(.subheadline)

            HStack {
                Button("Confirm") { onFeedback(.confirm, item) }
                Button("Wrong") { onFeedback(.wrong, item) }
                Button("Ignore") { onFeedback(.ignore, item) }
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct FeedbackPanel: View {
    let feedback: [BriefFeedback]
    let onClear: () -> Void

    var body: some View {
        if !feedback.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Feedback")
                        .font(.headline)
                    Spacer()
                    Button("Clear", action: onClear)
                        .buttonStyle(.bordered)
                }

                ForEach(feedback.suffix(5)) { item in
                    Text("\(item.kind.rawValue.capitalized): \(item.title)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding()
            .background(.thinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }
}

struct DiagnosticsPanel: View {
    let title: String
    let lines: [String]

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("\(title) (\(lines.count))")
                .font(.headline)
                .foregroundStyle(.red)

            ForEach(Array(lines.enumerated()), id: \.offset) { _, line in
                Text("* \(line)")
                    .font(.caption)
                    .foregroundStyle(.red)
            }
        }
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct DiagnosticsExportPanel: View {
    let snapshot: String
    let onCopy: () -> Void

    var body: some View {
        DisclosureGroup("Tester Debug Log") {
            VStack(alignment: .leading, spacing: 10) {
                Text(snapshot)
                    .font(.caption)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Button("Copy Debug Log", action: onCopy)
                    .buttonStyle(.bordered)
            }
        }
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
