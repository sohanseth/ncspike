import Foundation

struct PersonalContext: Codable, Equatable {
    var userName: String
    var partnerName: String
    var childNames: String
    var city: String

    static let empty = PersonalContext(
        userName: "",
        partnerName: "",
        childNames: "",
        city: ""
    )

    var isCompleteEnough: Bool {
        !userName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        !childNames.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        !city.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}

struct UserCapturedItem: Codable, Identifiable {
    let id: UUID
    let text: String
    let sourceLabel: String
    let taxonomy: String
    let capturedAt: Date

    init(
        id: UUID = UUID(),
        text: String,
        sourceLabel: String,
        taxonomy: String,
        capturedAt: Date = Date()
    ) {
        self.id = id
        self.text = text
        self.sourceLabel = sourceLabel
        self.taxonomy = taxonomy
        self.capturedAt = capturedAt
    }

    var fingerprint: String {
        ContentFingerprint.make(source: sourceLabel, text: text)
    }
}

enum BriefFeedbackKind: String, Codable {
    case confirm
    case wrong
    case ignore
}

struct BriefFeedback: Codable, Identifiable {
    let id: UUID
    let itemID: UUID
    let fingerprint: String?
    let title: String
    let source: String
    let kind: BriefFeedbackKind
    let createdAt: Date

    init(
        id: UUID = UUID(),
        itemID: UUID,
        fingerprint: String? = nil,
        title: String,
        source: String,
        kind: BriefFeedbackKind,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.itemID = itemID
        self.fingerprint = fingerprint
        self.title = title
        self.source = source
        self.kind = kind
        self.createdAt = createdAt
    }
}

enum ContentFingerprint {
    static func make(source: String, text: String) -> String {
        let normalizedSource = normalize(source)
        let normalizedText = normalize(text)
        return "\(normalizedSource)|\(normalizedText)"
    }

    static func normalize(_ value: String) -> String {
        value
            .lowercased()
            .replacingOccurrences(of: "\n", with: " ")
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }
}

enum UserContentStore {
    private static let profileKey = "v1.personalContext"
    private static let pastedItemsKey = "v1.pastedItems"
    private static let feedbackKey = "v1.feedback"

    static func loadProfile() -> PersonalContext {
        guard let data = UserDefaults.standard.data(forKey: profileKey),
              let profile = try? JSONDecoder().decode(PersonalContext.self, from: data) else {
            return .empty
        }
        return profile
    }

    static func saveProfile(_ profile: PersonalContext) {
        persist(profile, key: profileKey)
    }

    static func loadPastedItems() -> [UserCapturedItem] {
        loadArray(UserCapturedItem.self, key: pastedItemsKey)
    }

    static func addPastedItem(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let taxonomy = SharedItemClassifier.classify(trimmed).rawValue
        var items = loadPastedItems()
        let fingerprint = ContentFingerprint.make(source: "Paste", text: trimmed)
        items.removeAll { $0.fingerprint == fingerprint }
        items.append(UserCapturedItem(
            text: trimmed,
            sourceLabel: "Paste",
            taxonomy: taxonomy
        ))
        persist(items, key: pastedItemsKey)
    }

    static func clearPastedItems() {
        persist([UserCapturedItem](), key: pastedItemsKey)
    }

    static func loadFeedback() -> [BriefFeedback] {
        loadArray(BriefFeedback.self, key: feedbackKey)
    }

    static func addFeedback(_ feedback: BriefFeedback) {
        var all = loadFeedback()
        all.removeAll {
            $0.itemID == feedback.itemID ||
            ($0.fingerprint != nil && $0.fingerprint == feedback.fingerprint)
        }
        all.append(feedback)
        persist(all, key: feedbackKey)
    }

    static func clearFeedback() {
        persist([BriefFeedback](), key: feedbackKey)
    }

    private static func loadArray<T: Decodable>(_ type: T.Type, key: String) -> [T] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let items = try? JSONDecoder().decode([T].self, from: data) else {
            return []
        }
        return items
    }

    private static func persist<T: Encodable>(_ value: T, key: String) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}
