//
//  ncspikeApp.swift
//  ncspike
//
//  Created by Snehal Nair on 03/05/2026.
//

import SwiftUI

@main
struct ncspikeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
