import Foundation

let ncFixture = """
USER
Name: Priya
Location: Edinburgh
Timezone: Europe/London
Child: Maya, age 7
Partner: Ravi

CALENDAR
- 09:00 sprint planning
- 11:30 1:1 with manager
- 16:30 ballet pickup — Maya

EMAIL
- School: lunch payment due Friday
- Mum: Sunday email asking about Christmas plans
- Tesco: delivery confirmed 17:00–19:00 today
- Work: Slack notification summary for unread DMs
- Amazon: order shipped — ballet shoes

WHATSAPP SHARE
- Friend: "my mum is having hip surgery Wednesday morning — anxious"

AMBIGUOUS / ADVERSARIAL
- WhatsApp: "Can you bring it Friday?"
- Email says ballet shoes are arriving today, but no source says Maya needs them for today’s class.
"""
