import Foundation

// Fixture B — Adversarial
// Same personal context as Fixture A (Priya, Ravi, Maya age 7, Edinburgh).
// Every item is ambiguous, conflicting, vague, or stale.
// This is the real test. See runbook §3.1.

struct FixtureB {
    static let calendarEvents: [FixtureCalendarEvent] = [
        FixtureCalendarEvent(
            title: "Dentist",
            time: "09:00",
            rawText: "09:00 dentist (recurring monthly) — last month's was moved"
        ),
        FixtureCalendarEvent(
            title: "Meeting",
            time: "14:00",
            rawText: "14:00 meeting — no description, no attendees listed"
        ),
        FixtureCalendarEvent(
            title: "M school?",
            time: "17:30",
            rawText: "17:30 M school? — question mark in title, no description"
        )
    ]

    static let gmailMessages: [FixtureGmailMessage] = [
        FixtureGmailMessage(
            sender: "School",
            subject: "Important reminder",
            snippet: "Please note the deadline is this Wednesday."
        ),
        FixtureGmailMessage(
            sender: "Mrs Robertson",
            subject: "Following up",
            snippet: "Please return the form we discussed when you get a chance."
        ),
        FixtureGmailMessage(
            sender: "Ravi",
            subject: "Don't forget Friday",
            snippet: "Just a reminder — don't forget Friday."
        ),
        FixtureGmailMessage(
            sender: "Work Calendar",
            subject: "Team standup — missed",
            snippet: "You have not accepted this invite. The meeting was scheduled for yesterday."
        ),
        FixtureGmailMessage(
            sender: "School Photos",
            subject: "Photo day reminder — James",
            snippet: "School photo day reminder for James. Please ensure your child is in full uniform."
        )
    ]

    static let whatsappShares: [FixtureWhatsAppShare] = [
        FixtureWhatsAppShare(
            sender: "Class group",
            message: "Reminder: yellow on Friday for Children in Need"
        )
    ]
}
