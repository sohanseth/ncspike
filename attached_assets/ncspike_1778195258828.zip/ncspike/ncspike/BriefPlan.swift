import Foundation

enum BriefSource: String, Codable {
    case calendar
    case gmail
    case paste
    case whatsappShare
    case combined
}

enum BriefConfidence: String, Codable {
    case high = "High"
    case medium = "Medium"
    case low = "Low"
}

enum BriefTaxonomy: String, Codable {
    case work
    case schoolAdmin
    case household
    case childLogistics
    case relationshipMemory
    case sensitiveHealthAdjacent
    case ambiguous
    case general
}

// Verb risk tiers — planner must only emit commitment verbs when evidence is unambiguous.
//
// Soft    (safe always):        ask, check, confirm, review, save
// Action  (source-backed):      pack, pay, prepare, reply, send
// Commitment (strong evidence): attend, book, call, cancel, decide, ignore, schedule
//
// Rule: do not emit attend, book, call, cancel, or schedule unless the item is
// confirmed (High confidence) and the source is unambiguous (calendar or direct email).
enum SuggestedActionVerb: String, Codable, CaseIterable {
    case ask = "Ask"
    case attend = "Attend"
    case book = "Book"
    case call = "Call"
    case cancel = "Cancel"
    case check = "Check"
    case confirm = "Confirm"
    case decide = "Decide"
    case ignore = "Ignore"
    case pack = "Pack"
    case pay = "Pay"
    case prepare = "Prepare"
    case reply = "Reply"
    case review = "Review"
    case save = "Save"
    case schedule = "Schedule"
    case send = "Send"
}

struct PlannedBriefItem: Identifiable, Codable {
    let id: UUID
    let title: String
    let source: BriefSource
    let confidence: BriefConfidence
    let taxonomy: BriefTaxonomy
    let evidence: String
    let suggestedActionVerb: SuggestedActionVerb
    let suggestedActionObject: String
    let fingerprint: String

    init(
        id: UUID = UUID(),
        title: String,
        source: BriefSource,
        confidence: BriefConfidence,
        taxonomy: BriefTaxonomy,
        evidence: String,
        suggestedActionVerb: SuggestedActionVerb,
        suggestedActionObject: String,
        fingerprint: String? = nil
    ) {
        self.id = id
        self.title = title
        self.source = source
        self.confidence = confidence
        self.taxonomy = taxonomy
        self.evidence = evidence
        self.suggestedActionVerb = suggestedActionVerb
        self.suggestedActionObject = suggestedActionObject
        self.fingerprint = fingerprint ?? ContentFingerprint.make(source: source.rawValue, text: evidence)
    }
}

struct BriefPlan: Codable {
    let items: [PlannedBriefItem]
}
