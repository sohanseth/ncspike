import Foundation

enum DeterministicPlanner {
    static let maxBriefItems = 8

    // MARK: — v1 vertical slice

    static func makePlan(
        profile: PersonalContext,
        pastedItems: [UserCapturedItem],
        sharedItems: [SharedCapturedItem],
        feedback: [BriefFeedback]
    ) -> BriefPlan {
        let pastedPlanItems = pastedItems.map { item in
            plannedItem(
                id: item.id,
                text: item.text,
                sourceLabel: item.sourceLabel,
                source: .paste,
                taxonomyRaw: item.taxonomy,
                capturedAt: item.capturedAt,
                profile: profile
            )
        }

        let sharedPlanItems = sharedItems.map { item in
            plannedItem(
                id: item.id,
                text: item.message,
                sourceLabel: item.sender,
                source: .whatsappShare,
                taxonomyRaw: item.taxonomy,
                capturedAt: item.capturedAt,
                profile: profile
            )
        }

        let ignoredIDs = Set(feedback.filter { $0.kind == .ignore }.map(\.itemID))
        let wrongIDs = Set(feedback.filter { $0.kind == .wrong }.map(\.itemID))
        let confirmedIDs = Set(feedback.filter { $0.kind == .confirm }.map(\.itemID))
        let ignoredFingerprints = Set(feedback.filter { $0.kind == .ignore }.compactMap(\.fingerprint))
        let wrongFingerprints = Set(feedback.filter { $0.kind == .wrong }.compactMap(\.fingerprint))
        let confirmedFingerprints = Set(feedback.filter { $0.kind == .confirm }.compactMap(\.fingerprint))

        let ranked = deduplicated(pastedPlanItems + sharedPlanItems)
            .filter { !ignoredIDs.contains($0.id) && !ignoredFingerprints.contains($0.fingerprint) }
            .sorted { lhs, rhs in
                let left = priorityScore(
                    lhs,
                    confirmedIDs: confirmedIDs,
                    wrongIDs: wrongIDs,
                    confirmedFingerprints: confirmedFingerprints,
                    wrongFingerprints: wrongFingerprints
                )
                let right = priorityScore(
                    rhs,
                    confirmedIDs: confirmedIDs,
                    wrongIDs: wrongIDs,
                    confirmedFingerprints: confirmedFingerprints,
                    wrongFingerprints: wrongFingerprints
                )
                if left == right {
                    return lhs.title < rhs.title
                }
                return left > right
            }
            .prefix(maxBriefItems)

        return BriefPlan(items: Array(ranked))
    }

    private static func plannedItem(
        id: UUID,
        text: String,
        sourceLabel: String,
        source: BriefSource,
        taxonomyRaw: String,
        capturedAt: Date,
        profile: PersonalContext
    ) -> PlannedBriefItem {
        let taxonomy = BriefTaxonomy(rawValue: taxonomyRaw) ?? .general
        let confidence: BriefConfidence = taxonomy == .ambiguous ? .low : .medium
        let cleanText = text
            .replacingOccurrences(of: "\n", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let title = titleForCapturedText(cleanText)
        let (verb, actionObject) = actionForCapturedText(taxonomy: taxonomy, profile: profile)

        return PlannedBriefItem(
            id: id,
            title: title,
            source: source,
            confidence: confidence,
            taxonomy: taxonomy,
            evidence: "\(sourceLabel): \(cleanText). Captured at \(capturedAt.formatted(date: .omitted, time: .shortened))",
            suggestedActionVerb: verb,
            suggestedActionObject: actionObject,
            fingerprint: ContentFingerprint.make(source: sourceLabel, text: cleanText)
        )
    }

    private static func titleForCapturedText(_ text: String) -> String {
        if text.count <= 56 { return text }
        let prefix = String(text.prefix(56)).trimmingCharacters(in: .whitespacesAndNewlines)
        return "\(prefix)..."
    }

    private static func actionForCapturedText(
        taxonomy: BriefTaxonomy,
        profile: PersonalContext
    ) -> (SuggestedActionVerb, String) {
        switch taxonomy {
        case .sensitiveHealthAdjacent:
            return (.save, "a gentle reminder to follow up")
        case .childLogistics:
            let childContext = profile.childNames.isEmpty ? "the child logistics" : profile.childNames
            return (.confirm, "what is needed for \(childContext)")
        case .schoolAdmin:
            return (.check, "what school action this requires")
        case .household:
            return (.check, "whether this needs action today")
        case .ambiguous:
            return (.ask, "what the sender needs from you")
        case .relationshipMemory:
            return (.save, "a reminder if this matters later")
        case .work:
            return (.review, "whether this belongs in today's brief")
        case .general:
            return (.confirm, "whether this needs a reply")
        }
    }

    private static func priorityScore(
        _ item: PlannedBriefItem,
        confirmedIDs: Set<UUID>,
        wrongIDs: Set<UUID>,
        confirmedFingerprints: Set<String>,
        wrongFingerprints: Set<String>
    ) -> Int {
        var score: Int
        switch item.taxonomy {
        case .sensitiveHealthAdjacent: score = 95
        case .schoolAdmin: score = 85
        case .childLogistics: score = 80
        case .household: score = 65
        case .ambiguous: score = 60
        case .relationshipMemory: score = 55
        case .general: score = 45
        case .work: score = 35
        }

        switch item.confidence {
        case .high: score += 10
        case .medium: score += 4
        case .low: score -= 4
        }

        if confirmedIDs.contains(item.id) || confirmedFingerprints.contains(item.fingerprint) { score += 12 }
        if wrongIDs.contains(item.id) || wrongFingerprints.contains(item.fingerprint) { score -= 30 }
        return score
    }

    private static func deduplicated(_ items: [PlannedBriefItem]) -> [PlannedBriefItem] {
        var latestByFingerprint: [String: PlannedBriefItem] = [:]
        for item in items {
            latestByFingerprint[item.fingerprint] = item
        }
        return latestByFingerprint.values.sorted { $0.title < $1.title }
    }

    static func makePlanFromFixtureA() -> BriefPlan {
        var items: [PlannedBriefItem] = []

        // Rule 1:
        // Every calendar event today becomes High confidence calendar item.
        // Verb is taxonomy-specific: childLogistics → attend (pickup is a commitment);
        // work → filtered below; general → review.
        for event in FixtureA.calendarEvents {
            let taxonomy = classifyCalendarEvent(event)
            let (verb, actionObject): (SuggestedActionVerb, String) = {
                switch taxonomy {
                case .childLogistics:
                    return (.attend, "\(event.title.lowercased()) at the scheduled time")
                case .work:
                    return (.attend, event.title.lowercased())
                default:
                    return (.review, "this event before it starts")
                }
            }()
            items.append(
                PlannedBriefItem(
                    title: event.title,
                    source: .calendar,
                    confidence: .high,
                    taxonomy: taxonomy,
                    evidence: event.rawText,
                    suggestedActionVerb: verb,
                    suggestedActionObject: actionObject
                )
            )
        }

        // Rule 2:
        // Gmail messages with date/deadline keywords become Medium or High items.
        for message in FixtureA.gmailMessages {
            let subject = message.subject.lowercased()
            let snippet = message.snippet.lowercased()
            let combined = subject + " " + snippet

            if combined.contains("due") || combined.contains("friday") {
                items.append(
                    PlannedBriefItem(
                        title: message.subject,
                        source: .gmail,
                        confidence: .high,
                        taxonomy: .schoolAdmin,
                        evidence: "\(message.sender): \(message.subject). \(message.snippet)",
                        suggestedActionVerb: .pay,
                        suggestedActionObject: "or confirm it is already handled"
                    )
                )
            } else if combined.contains("delivery") || combined.contains("today") {
                items.append(
                    PlannedBriefItem(
                        title: "Tesco delivery confirmed today",
                        source: .gmail,
                        confidence: .medium,
                        taxonomy: .household,
                        evidence: "\(message.sender): \(message.subject). \(message.snippet)",
                        suggestedActionVerb: .check,
                        suggestedActionObject: "who can receive the delivery"
                    )
                )
            } else if combined.contains("ballet shoes") {
                items.append(
                    PlannedBriefItem(
                        title: "Ballet shoes arriving",
                        source: .gmail,
                        confidence: .medium,
                        taxonomy: .childLogistics,
                        evidence: "\(message.sender): \(message.subject). \(message.snippet)",
                        suggestedActionVerb: .check,
                        suggestedActionObject: "delivery timing before assuming they matter today"
                    )
                )
            } else if combined.contains("christmas") {
                items.append(
                    PlannedBriefItem(
                        title: "Christmas plans message from Mum",
                        source: .gmail,
                        confidence: .low,
                        taxonomy: .relationshipMemory,
                        evidence: "\(message.sender): \(message.subject). \(message.snippet)",
                        suggestedActionVerb: .reply,
                        suggestedActionObject: "when you have space"
                    )
                )
            }
        }

        // Rule 3:
        // WhatsApp health-adjacent message becomes sensitive relationship-memory prompt.
        for share in FixtureA.whatsappShares {
            let text = share.message.lowercased()

            if text.contains("surgery") || text.contains("anxious") {
                items.append(
                    PlannedBriefItem(
                        title: "Friend's mum has surgery Wednesday",
                        source: .whatsappShare,
                        confidence: .medium,
                        taxonomy: .sensitiveHealthAdjacent,
                        evidence: "\(share.sender): \(share.message)",
                        suggestedActionVerb: .save,
                        suggestedActionObject: "a gentle reminder to ask how it went"
                    )
                )
            } else if text.contains("bring it") {
                items.append(
                    PlannedBriefItem(
                        title: "Ambiguous Friday request",
                        source: .whatsappShare,
                        confidence: .low,
                        taxonomy: .ambiguous,
                        evidence: "\(share.sender): \(share.message)",
                        suggestedActionVerb: .ask,
                        suggestedActionObject: "what “it” refers to"
                    )
                )
            }
        }

        // Deliberately dumb v1 rule:
        // Keep only the most useful items for Morning Brief.
        // This prevents generic work-calendar sludge.
        let filtered = items.filter { item in
            switch item.taxonomy {
            case .work:
                return false
            default:
                return true
            }
        }

        return BriefPlan(items: filtered)
    }

    // MARK: — Fixture B (adversarial)

    static func makePlanFromFixtureB() -> BriefPlan {
        var items: [PlannedBriefItem] = []

        // Rule 1: Calendar — conservative classification
        for event in FixtureB.calendarEvents {
            let title = event.title.lowercased()

            // "?" in title → planner cannot resolve → surface as ambiguous
            if title.contains("?") {
                items.append(PlannedBriefItem(
                    title: "\(event.time) — '\(event.title)' (title unclear)",
                    source: .calendar,
                    confidence: .low,
                    taxonomy: .ambiguous,
                    evidence: event.rawText,
                    suggestedActionVerb: .confirm,
                    suggestedActionObject: "what this event means before \(event.time)"
                ))
            // No description at all — suppress. Zero actionable info;
            // user can check their own calendar. Surfacing it is noise.
            } else if title == "meeting" {
                continue
            // Identifiable personal event
            } else {
                items.append(PlannedBriefItem(
                    title: "\(event.title) at \(event.time)",
                    source: .calendar,
                    confidence: .medium,
                    taxonomy: classifyCalendarEvent(event),
                    evidence: event.rawText,
                    suggestedActionVerb: .attend,
                    suggestedActionObject: "\(event.title.lowercased()) at \(event.time)"
                ))
            }
        }

        // Rule 2: Gmail — conservative; filter stale; flag wrong-child
        for message in FixtureB.gmailMessages {
            let subject = message.subject.lowercased()
            let snippet = message.snippet.lowercased()
            let combined = subject + " " + snippet

            // Stale event — filter out
            if combined.contains("yesterday") {
                continue
            }

            // Wrong child's name — surface as check-required
            if combined.contains("james") {
                items.append(PlannedBriefItem(
                    title: "School photo day — wrong child's name (James, not Maya)",
                    source: .gmail,
                    confidence: .medium,
                    taxonomy: .schoolAdmin,
                    evidence: "\(message.sender): \(message.subject). \(message.snippet)",
                    suggestedActionVerb: .check,
                    suggestedActionObject: "whether this email was meant for you"
                ))

            // "This Wednesday" — no specific date
            } else if combined.contains("wednesday") {
                items.append(PlannedBriefItem(
                    title: "School deadline: 'this Wednesday' — date not specified",
                    source: .gmail,
                    confidence: .low,
                    taxonomy: .schoolAdmin,
                    evidence: "\(message.sender): \(message.snippet)",
                    suggestedActionVerb: .check,
                    suggestedActionObject: "which Wednesday and what action is needed"
                ))

            // Vague form reference — no link, no form name
            } else if combined.contains("form we discussed") {
                items.append(PlannedBriefItem(
                    title: "Teacher waiting for a form — no details in email",
                    source: .gmail,
                    confidence: .low,
                    taxonomy: .schoolAdmin,
                    evidence: "\(message.sender): \(message.snippet)",
                    suggestedActionVerb: .reply,
                    suggestedActionObject: "to clarify which form is needed"
                ))

            // Partner "Friday" — no Friday context anywhere
            } else if combined.contains("friday") {
                items.append(PlannedBriefItem(
                    title: "Ravi: 'Don't forget Friday' — no context",
                    source: .gmail,
                    confidence: .low,
                    taxonomy: .ambiguous,
                    evidence: "\(message.sender): \(message.snippet)",
                    suggestedActionVerb: .ask,
                    suggestedActionObject: "Ravi what Friday refers to"
                ))
            }
        }

        // Rule 3: WhatsApp — class group message, two children, year group not stated
        for share in FixtureB.whatsappShares {
            let text = share.message.lowercased()

            if text.contains("yellow") || text.contains("children in need") {
                items.append(PlannedBriefItem(
                    title: "Yellow on Friday — Children in Need (which child?)",
                    source: .whatsappShare,
                    confidence: .low,
                    taxonomy: .ambiguous,
                    evidence: "\(share.sender): \(share.message)",
                    suggestedActionVerb: .confirm,
                    suggestedActionObject: "which year group this applies to"
                ))
            }
        }

        return BriefPlan(items: items)
    }

    // MARK: — Captured items (from Share Extension via App Group)

    static func appendCapturedItems(to plan: BriefPlan) -> BriefPlan {
        let captured = SharedStorage.loadAll()
        guard !captured.isEmpty else { return plan }

        let newItems: [PlannedBriefItem] = captured.map { item in
            let taxonomy = BriefTaxonomy(rawValue: item.taxonomy) ?? .general
            let confidence: BriefConfidence = taxonomy == .ambiguous ? .low : .medium
            let title = String(item.message.prefix(60))
                .replacingOccurrences(of: "\n", with: " ")
                .trimmingCharacters(in: .whitespaces)

            let (verb, actionObject): (SuggestedActionVerb, String) = {
                switch taxonomy {
                case .sensitiveHealthAdjacent:
                    return (.save, "a gentle reminder to follow up")
                case .childLogistics:
                    return (.confirm, "what is needed from you")
                case .schoolAdmin:
                    return (.check, "what action this requires")
                case .household:
                    return (.check, "whether this needs action today")
                case .ambiguous:
                    return (.ask, "what the sender needs from you")
                case .relationshipMemory, .work, .general:
                    return (.confirm, "whether this needs a reply")
                }
            }()

            return PlannedBriefItem(
                title: title,
                source: .whatsappShare,
                confidence: confidence,
                taxonomy: taxonomy,
                evidence: "\(item.sender): \(item.message)",
                suggestedActionVerb: verb,
                suggestedActionObject: actionObject
            )
        }

        return BriefPlan(items: plan.items + newItems)
    }

    private static func classifyCalendarEvent(_ event: FixtureCalendarEvent) -> BriefTaxonomy {
        let text = event.rawText.lowercased()

        if text.contains("ballet") || text.contains("maya") {
            return .childLogistics
        }

        if text.contains("sprint") || text.contains("manager") {
            return .work
        }

        return .general
    }
}
