import Foundation

// Keyword-based classifier for Share Extension.
// NO LLM here — must be synchronous and offline-capable.
// Full LLM reclassification happens in the main app at brief-generation time.

enum SharedTaxonomy: String {
    case sensitiveHealthAdjacent
    case childLogistics
    case schoolAdmin
    case household
    case ambiguous
    case general

    var displayName: String {
        switch self {
        case .sensitiveHealthAdjacent: return "Health / sensitive"
        case .childLogistics:          return "Child logistics"
        case .schoolAdmin:             return "School admin"
        case .household:               return "Household"
        case .ambiguous:               return "Needs clarification"
        case .general:                 return "General"
        }
    }
}

enum SharedItemClassifier {
    static func classify(_ text: String) -> SharedTaxonomy {
        let t = text.lowercased()

        if t.contains("surgery") || t.contains("hospital") || t.contains("diagnosis") ||
           t.contains("anxious") || t.contains("cancer") || t.contains("chemo") ||
           t.contains("ill ") || t.contains("unwell") || t.contains("test results") {
            return .sensitiveHealthAdjacent
        }

        if t.contains("pickup") || t.contains("pick up") || t.contains("drop off") ||
           t.contains("ballet") || t.contains("school run") || t.contains("collect") ||
           t.contains("nursery") || t.contains("childminder") || t.contains("after school") {
            return .childLogistics
        }

        if t.contains("school") || t.contains("teacher") || t.contains("homework") ||
           t.contains("uniform") || t.contains("permission slip") || t.contains("photo day") ||
           t.contains("story time") || t.contains("parents evening") || t.contains("inset") {
            return .schoolAdmin
        }

        if t.contains("delivery") || t.contains("tesco") || t.contains("amazon") ||
           t.contains("groceries") || t.contains("grocery") || t.contains("order") ||
           t.contains("dinner") || t.contains("lunch") || t.contains("breakfast") ||
           t.contains("meal") || t.contains("food") || t.contains("shopping") ||
           t.contains("cook") || t.contains("recipe") || t.contains("washing") ||
           t.contains("cleaning") || t.contains("milk") || t.contains("bread") ||
           t.contains("sports centre") || t.contains("leisure centre") {
            return .household
        }

        // Multi-item lists → household.
        // Newline-separated: ≥2 newlines = ≥3 lines = clearly a list.
        // Comma-separated: use whitespace-aware word count to avoid the space-only split trap.
        let commaCount = t.filter { $0 == "," }.count
        let newlineCount = t.filter { $0 == "\n" }.count
        let wordCount = t.split { $0.isWhitespace }.count
        if newlineCount >= 2 || (commaCount >= 1 && wordCount >= 3) {
            return .household
        }

        // Short messages with vague pronouns are ambiguous
        if wordCount < 8 && (t.contains(" it") || t.contains("friday") || t.contains("tomorrow")) {
            return .ambiguous
        }

        return .general
    }
}
