import Foundation

// ModelBriefItem and BriefResponse (@Generable schema-constrained generation) removed.
// Confirmed non-viable at spike gate 6: structured output returned blank.
// Architecture decision (gate 9): use text-emit + Swift parser instead.
// See runbook §3 diagnosis — structured output gap.
