import UIKit
import UniformTypeIdentifiers

// NCShare — Share Extension
// Goal: receive text from WhatsApp share sheet, classify it, store to App Group,
// show confirmation, dismiss. No LLM. Must be < 2s end-to-end.

class ShareViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        extractSharedText()
    }

    private func extractSharedText() {
        guard let item = extensionContext?.inputItems.first as? NSExtensionItem,
              let provider = item.attachments?.first else {
            showResult(message: "Nothing to capture", isSuccess: false)
            return
        }

        let textType = UTType.plainText.identifier

        if provider.hasItemConformingToTypeIdentifier(textType) {
            provider.loadItem(forTypeIdentifier: textType) { [weak self] result, _ in
                DispatchQueue.main.async {
                    if let text = result as? String, !text.isEmpty {
                        self?.capture(text)
                    } else {
                        self?.showResult(message: "Could not read text", isSuccess: false)
                    }
                }
            }
        } else {
            showResult(message: "NC only captures text messages", isSuccess: false)
        }
    }

    private func capture(_ text: String) {
        let taxonomy = SharedItemClassifier.classify(text)
        let item = SharedCapturedItem(
            message: text,
            sender: "WhatsApp share",
            taxonomy: taxonomy.rawValue
        )
        SharedStorage.save(item)
        let preview = text.count > 56 ? "\(text.prefix(56))..." : text
        showResult(message: "Saved. Open NC Spike and tap Reload Shares. \(taxonomy.displayName): \(preview)", isSuccess: true)
    }

    private func showResult(message: String, isSuccess: Bool) {
        view.backgroundColor = .systemBackground

        let icon = UILabel()
        icon.text = isSuccess ? "✓" : "✕"
        icon.font = .systemFont(ofSize: 36, weight: .medium)
        icon.textColor = isSuccess ? .systemGreen : .systemRed
        icon.textAlignment = .center

        let title = UILabel()
        title.text = isSuccess ? "Saved to NC" : "Not saved"
        title.font = .systemFont(ofSize: 17, weight: .semibold)
        title.textAlignment = .center

        let subtitle = UILabel()
        subtitle.text = message
        subtitle.font = .systemFont(ofSize: 13)
        subtitle.textColor = .secondaryLabel
        subtitle.textAlignment = .center
        subtitle.numberOfLines = 4

        let stack = UIStackView(arrangedSubviews: [icon, title, subtitle])
        stack.axis = .vertical
        stack.spacing = 6
        stack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24)
        ])

        // Give users enough time to see the save confirmation.
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { [weak self] in
            self?.extensionContext?.completeRequest(returningItems: [], completionHandler: nil)
        }
    }
}
