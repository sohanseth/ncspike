import Foundation

enum SharedStorage {
    static let appGroupID = "group.nc.spike"
    private static let itemsKey = "capturedItems"

    static func save(_ item: SharedCapturedItem) {
        var items = loadAll()
        items.removeAll { $0.fingerprint == item.fingerprint }
        items.append(item)
        persist(Array(items.suffix(50)))
    }

    static func loadAll() -> [SharedCapturedItem] {
        guard let defaults = UserDefaults(suiteName: appGroupID),
              let data = defaults.data(forKey: itemsKey),
              let items = try? JSONDecoder().decode([SharedCapturedItem].self, from: data) else {
            return []
        }
        return deduplicated(items)
    }

    private static func persist(_ items: [SharedCapturedItem]) {
        guard let defaults = UserDefaults(suiteName: appGroupID),
              let data = try? JSONEncoder().encode(items) else { return }
        defaults.set(data, forKey: itemsKey)
        defaults.synchronize()
    }

    private static func deduplicated(_ items: [SharedCapturedItem]) -> [SharedCapturedItem] {
        var latestByFingerprint: [String: SharedCapturedItem] = [:]
        for item in items {
            latestByFingerprint[item.fingerprint] = item
        }
        return latestByFingerprint.values.sorted { $0.capturedAt < $1.capturedAt }
    }
}
