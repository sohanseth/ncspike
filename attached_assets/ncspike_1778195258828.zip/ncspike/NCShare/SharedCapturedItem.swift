import Foundation

struct SharedCapturedItem: Codable, Identifiable {
    let id: UUID
    let message: String
    let sender: String
    let taxonomy: String
    let capturedAt: Date

    init(
        id: UUID = UUID(),
        message: String,
        sender: String,
        taxonomy: String,
        capturedAt: Date = Date()
    ) {
        self.id = id
        self.message = message
        self.sender = sender
        self.taxonomy = taxonomy
        self.capturedAt = capturedAt
    }

    var fingerprint: String {
        SharedContentFingerprint.make(source: sender, text: message)
    }
}

enum SharedContentFingerprint {
    static func make(source: String, text: String) -> String {
        "\(normalize(source))|\(normalize(text))"
    }

    private static func normalize(_ value: String) -> String {
        value
            .lowercased()
            .replacingOccurrences(of: "\n", with: " ")
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }
}
